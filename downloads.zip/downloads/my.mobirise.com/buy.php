    <!DOCTYPE html>
<meta charset="UTF-8">

    <html lang="en">
    <head>
            <meta http-equiv="X-UA-Compatible" content="IE=Edge" />
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8">

        <script type="text/javascript">
            var STATIC_CONTENT_DEFAULT_SERVER_ROOT_URL = 'https://secure.2checkout.com';
            var SPACER_IMAGE = '/images/spacer.gif?20250630164206';

            var d = new Date() ;
            var scStartTime = d.getTime();

                    </script>
        <title>Mobirise Premium Themes and Extensions - Order Now!</title>

        
                        


    
                        
    
    
                
    
    



    
    
    
                



    
    
    








                    
            
        
        
        <link rel="stylesheet" type="text/css" href="https://secure.avangate.com/static/css-order-03e7a650a4df6e0c2077f07aa1073acc-V110/20250630164206.css">

<style type="text/css">
	    .sprite-icons-payments { background-image: url(/images/order/sprite-icons-payments.gif?20250630164206); padding:0; margin:0; border:0; width: 32px; height: 22px; }



</style>

        <meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://secure.avangate.com/static/css-order-bf95905becc1c815832b189e540dd02e-V110/20250618185607.css">

<style>
/* 
  * Ava Icons
  * 
  * @version 1.0.0
  */
  @font-face{
    font-family:AvaIcons;
    src:url('/images/merchant/675f9820626f5bc0afb47b57890b466e/avaicons.eot');
    src:url('/images/merchant/675f9820626f5bc0afb47b57890b466e/avaicons.eot?#iefix') format("embedded-opentype"),
      url('/images/merchant/675f9820626f5bc0afb47b57890b466e/avaicons.woff') format("woff"),
      url('/images/merchant/675f9820626f5bc0afb47b57890b466e/avaicons.ttf') format("truetype"),
      url('/images/merchant/675f9820626f5bc0afb47b57890b466e/avaicons.svg#avaicons') format("svg");
    font-weight:400;
    font-style:normal
  }
  .ie-before,
  [class*=" icon-"]:before,
  [class^=icon-]:before{
    font-family:AvaIcons!important;
    font-style:normal!important;
    font-weight:400!important;
    font-variant:normal!important;
    text-transform:none!important;
    speak:none;
    line-height:1;
    -webkit-font-smoothing:antialiased;
    -moz-osx-font-smoothing:grayscale
  }
  .icon-coupon .ie-before,
  .icon-coupon:before{content:"a"}
  .icon-phone .ie-before,
  .icon-phone:before{content:"b"}
  .icon-placeorder .ie-before,
  .icon-placeorder:before{content:"c"}
  .icon-refresh .ie-before,
  .icon-refresh:before{content:"d"}
  .icon-lifebuoy .ie-before,
  .icon-lifebuoy:before{content:"e"}
  .icon-paypal .ie-before,
  .icon-paypal:before{content:"f"}
  .icon-search-find .ie-before,
  .icon-search-find:before{content:"g"}
  .icon-align-justify .ie-before,
  .icon-align-justify:before{content:"h"}
  .icon-mail .ie-before,
  .icon-mail:before{content:"i"}
  .icon-check .ie-before,
  .icon-check:before{content:"j"}
  .icon-close .ie-before,
  .icon-close:before{content:"k"}
  .icon-trash-bin .ie-before,
  .icon-trash-bin:before{content:"l"}
  .icon-home .ie-before,
  .icon-home:before{content:"m"}
  .icon-download .ie-before,
  .icon-download:before{content:"n"}
  .icon-cloud-download- .ie-before,
  .icon-cloud-download:before{content:"o"}
  .icon-cd .ie-before,
  .icon-cd:before{content:"p"}
  .icon-gift .ie-before,
  .icon-gift:before{content:"q"}
  .icon-lock .ie-before,
  .icon-lock:before{content:"r"}
  .icon-credit-card .ie-before,
  .icon-credit-card:before{content:"s"}
  .icon-left-open .ie-before,
  .icon-left-open:before{content:"t"}
  .icon-down-open .ie-before,
  .icon-down-open:before{content:"u"}
  .icon-up-open .ie-before,
  .icon-up-open:before{content:"v"}
  .icon-right-open .ie-before,
  .icon-right-open:before{content:"w"}
  .icon-exclamation-circle .ie-before,
  .icon-exclamation-circle:before{content:"x"}
  .icon-info-circled .ie-before,
  .icon-info-circled:before{content:"y"}

  /* 
  * Page Preloader
  */
  .coupon-placeholder {display:none}
  .auto-renewal-display {display:none}
  .page-preloader {
    background: #fff url("/images/merchant/67caec8041b2d689a5035d3bf441c34c/gif-load.gif?20150618161130") no-repeat scroll center center !important;
    height: 100% !important;
    left: 0  !important;
    position: fixed  !important;
    top: 0  !important;
    width: 100%  !important;
    z-index: 99999 !important;
  }
  
</style>

 <!-- Google Tag Manager-->
 <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-PFK425');window.sessionStorage.setItem('renewal-option','true');</script>
<!-- End Google Tag Manager --> 

                            </head>

    <body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
    
            <noscript>
            <div class="general_top_nojs_alert"><img src="/images/spacer.gif?20250630164206" alt="Additional Information" class="sprite sprite-warning-ico-16px" /> For the shopping cart to work properly you'll need to <strong>enable JavaScript</strong>. <a href="/order/nojs.php?CART_ID=448f9aa180c57616de7927eb0715cf2c" target="_blank">Find out how</a>.</div>
        </noscript>
    
    <div class="page-preloader"></div>

                <div id="order__container">
                
<form method="post" action="https://secure.avangate.com/order/checkout.php?CART_ID=448f9aa180c57616de7927eb0715cf2c" name="frmCheckout" id="frmCheckout" class="order__form__main order__form__checkout order__form__checkcart" style="margin:0px;">
        <input type="hidden" name="action" id="action" value="" />
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
            <td>
                <div id="order__page__checkcart" class="order__page">
                                            <div id="order__header">
                            <div id="order__header__languages">
                                <span id="order__header__languages__text"> Language: </span>
                                <select aria-label="Language" name='language' onchange="$('#action').val('language');$('#userChosenAction').val('language'); this.form.submit();">
                                                                            <option value="ar" >
                                            العربية
                                        </option>
                                                                            <option value="bg" >
                                            български език
                                        </option>
                                                                            <option value="zh" >
                                            中文
                                        </option>
                                                                            <option value="zy" >
                                            繁體中文
                                        </option>
                                                                            <option value="hr" >
                                            Hrvatski jezik
                                        </option>
                                                                            <option value="cs" >
                                            Česky
                                        </option>
                                                                            <option value="da" >
                                            Dansk
                                        </option>
                                                                            <option value="nl" >
                                            Nederlands
                                        </option>
                                                                            <option value="en" selected>
                                            English
                                        </option>
                                                                            <option value="fi" >
                                            Suomi
                                        </option>
                                                                            <option value="fr" >
                                            Français
                                        </option>
                                                                            <option value="de" >
                                            Deutsch
                                        </option>
                                                                            <option value="el" >
                                            Ελληνικά
                                        </option>
                                                                            <option value="hi" >
                                            Hindi
                                        </option>
                                                                            <option value="hu" >
                                            Magyar
                                        </option>
                                                                            <option value="it" >
                                            Italiano
                                        </option>
                                                                            <option value="ja" >
                                            日本語
                                        </option>
                                                                            <option value="ko" >
                                            한국어
                                        </option>
                                                                            <option value="no" >
                                            Norsk
                                        </option>
                                                                            <option value="fa" >
                                            فارسی
                                        </option>
                                                                            <option value="pl" >
                                            Polski
                                        </option>
                                                                            <option value="pt" >
                                            Português
                                        </option>
                                                                            <option value="pt-br" >
                                            Português do Brasil
                                        </option>
                                                                            <option value="ro" >
                                            Română
                                        </option>
                                                                            <option value="ru" >
                                            Русский
                                        </option>
                                                                            <option value="sk" >
                                            Slovenčina
                                        </option>
                                                                            <option value="sl" >
                                            Slovène
                                        </option>
                                                                            <option value="es" >
                                            Español
                                        </option>
                                                                            <option value="sv" >
                                            Svenska
                                        </option>
                                                                            <option value="th" >
                                            ไทย
                                        </option>
                                                                            <option value="tr" >
                                            Türkçe
                                        </option>
                                                                    </select>
                                <noscript>
                                    <input aria-label="Go" type="submit" value="Go">
                                </noscript>
                            </div>

                            <div id="order__header__currencies" class="order__checkout__form__billing__currencies">
                                <span id="order__header__currencies__text"> Show price in: </span>

                                <select aria-label="Show price in" name='display_currency' onchange="$('#action').val('currency');$('#userChosenAction').val('currency');refreshContent()">
                                                                                                                        <option value="AED" >
                                                AED - United Arab Emirates Dirham
                                            </option>
                                                                                                                                                                <option value="AFN" >
                                                AFN - Afghan Afghani
                                            </option>
                                                                                                                                                                <option value="ALL" >
                                                ALL - Albanian Lek
                                            </option>
                                                                                                                                                                <option value="ARS" >
                                                ARS - Argentine Peso
                                            </option>
                                                                                                                                                                <option value="AUD" >
                                                AUD - Australian Dollar
                                            </option>
                                                                                                                                                                <option value="AZN" >
                                                AZN - Azerbaijan Manat
                                            </option>
                                                                                                                                                                <option value="BBD" >
                                                BBD - Barbadian dollar
                                            </option>
                                                                                                                                                                <option value="BDT" >
                                                BDT - Bangladeshi Taka
                                            </option>
                                                                                                                                                                <option value="BGN" >
                                                BGN - Bulgarian Lev
                                            </option>
                                                                                                                                                                <option value="BHD" >
                                                BHD - Bahrain Dinar
                                            </option>
                                                                                                                                                                <option value="BMD" >
                                                BMD - Bermudian Dollar
                                            </option>
                                                                                                                                                                <option value="BND" >
                                                BND - Bruneian Dollar
                                            </option>
                                                                                                                                                                <option value="BOB" >
                                                BOB - Bolivian peso
                                            </option>
                                                                                                                                                                <option value="BRL" selected>
                                                BRL - Brazilian Real
                                            </option>
                                                                                                                                                                <option value="BSD" >
                                                BSD - Bahamian Dollar
                                            </option>
                                                                                                                                                                <option value="BWP" >
                                                BWP - Botswana Pula
                                            </option>
                                                                                                                                                                <option value="BYN" >
                                                BYN - Belarusian Ruble
                                            </option>
                                                                                                                                                                <option value="BYR" >
                                                BYR - Belarusian Ruble
                                            </option>
                                                                                                                                                                <option value="BZD" >
                                                BZD - Belizean Dollar
                                            </option>
                                                                                                                                                                <option value="CAD" >
                                                CAD - Canadian Dollar
                                            </option>
                                                                                                                                                                <option value="CHF" >
                                                CHF - Swiss Franc
                                            </option>
                                                                                                                                                                <option value="CLP" >
                                                CLP - Chilean Peso
                                            </option>
                                                                                                                                                                <option value="CNY" >
                                                CNY - China Yuan Renminbi
                                            </option>
                                                                                                                                                                <option value="COP" >
                                                COP - Colombian Peso
                                            </option>
                                                                                                                                                                <option value="CRC" >
                                                CRC - Costa Rican Colon
                                            </option>
                                                                                                                                                                <option value="CZK" >
                                                CZK - Czech Koruna
                                            </option>
                                                                                                                                                                <option value="DKK" >
                                                DKK - Danish Krone
                                            </option>
                                                                                                                                                                <option value="DOP" >
                                                DOP - Dominican Peso
                                            </option>
                                                                                                                                                                <option value="DZD" >
                                                DZD - Algerian Dinar
                                            </option>
                                                                                                                                                                <option value="EGP" >
                                                EGP - Egyptian Pound
                                            </option>
                                                                                                                                                                <option value="EUR" >
                                                EUR - Euro
                                            </option>
                                                                                                                                                                <option value="FJD" >
                                                FJD - Fijian Dollar
                                            </option>
                                                                                                                                                                <option value="GBP" >
                                                GBP - Great British Pound
                                            </option>
                                                                                                                                                                <option value="GEL" >
                                                GEL - Georgian Lari
                                            </option>
                                                                                                                                                                <option value="GTQ" >
                                                GTQ - Guatemalan Quetzal
                                            </option>
                                                                                                                                                                <option value="HKD" >
                                                HKD - Hong Kong Dollar
                                            </option>
                                                                                                                                                                <option value="HNL" >
                                                HNL - Honduran Lempira
                                            </option>
                                                                                                                                                                <option value="HRK" >
                                                HRK - Croatian Kuna
                                            </option>
                                                                                                                                                                <option value="HTG" >
                                                HTG - Haitian Gourde
                                            </option>
                                                                                                                                                                <option value="HUF" >
                                                HUF - Hungarian Forint
                                            </option>
                                                                                                                                                                <option value="IDR" >
                                                IDR - Indonesian Rupiah
                                            </option>
                                                                                                                                                                <option value="ILS" >
                                                ILS - Israeli New Sheqel
                                            </option>
                                                                                                                                                                <option value="INR" >
                                                INR - Indian Rupee
                                            </option>
                                                                                                                                                                <option value="JMD" >
                                                JMD - Jamaican Dollar
                                            </option>
                                                                                                                                                                <option value="JOD" >
                                                JOD - Jordanian Dinar
                                            </option>
                                                                                                                                                                <option value="JPY" >
                                                JPY - Japanese Yen
                                            </option>
                                                                                                                                                                <option value="KES" >
                                                KES - Kenyan Shilling
                                            </option>
                                                                                                                                                                <option value="KRW" >
                                                KRW - South Korean Won
                                            </option>
                                                                                                                                                                <option value="KWD" >
                                                KWD - Kuwaiti Dinar
                                            </option>
                                                                                                                                                                <option value="KZT" >
                                                KZT - Kazakhstani Tenge
                                            </option>
                                                                                                                                                                <option value="LAK" >
                                                LAK - Laotian Kip
                                            </option>
                                                                                                                                                                <option value="LBP" >
                                                LBP - Lebanese Pound
                                            </option>
                                                                                                                                                                <option value="LKR" >
                                                LKR - Sri Lankan Rupee
                                            </option>
                                                                                                                                                                <option value="LRD" >
                                                LRD - Liberian Dollar
                                            </option>
                                                                                                                                                                <option value="MAD" >
                                                MAD - Moroccan Dirham
                                            </option>
                                                                                                                                                                <option value="MDL" >
                                                MDL - Moldavian Lei
                                            </option>
                                                                                                                                                                <option value="MMK" >
                                                MMK - Myanmar Kyat
                                            </option>
                                                                                                                                                                <option value="MOP" >
                                                MOP - Macanese Pataca
                                            </option>
                                                                                                                                                                <option value="MRO" >
                                                MRO - Mauritanian Ouguiya
                                            </option>
                                                                                                                                                                <option value="MUR" >
                                                MUR - Mauritian Rupee
                                            </option>
                                                                                                                                                                <option value="MVR" >
                                                MVR - Maldivian Rufiyaa
                                            </option>
                                                                                                                                                                <option value="MXN" >
                                                MXN - Mexican Peso
                                            </option>
                                                                                                                                                                <option value="MYR" >
                                                MYR - Malaysian Ringgit
                                            </option>
                                                                                                                                                                <option value="NAD" >
                                                NAD - Namibian dollar
                                            </option>
                                                                                                                                                                <option value="NGN" >
                                                NGN - Nigerian naira
                                            </option>
                                                                                                                                                                <option value="NIO" >
                                                NIO - Nicaraguan Córdoba
                                            </option>
                                                                                                                                                                <option value="NOK" >
                                                NOK - Norwegian Krone
                                            </option>
                                                                                                                                                                <option value="NPR" >
                                                NPR - Nepalese Rupee
                                            </option>
                                                                                                                                                                <option value="NZD" >
                                                NZD - New Zealand Dollars
                                            </option>
                                                                                                                                                                <option value="OMR" >
                                                OMR - Omani Rial
                                            </option>
                                                                                                                                                                <option value="PAB" >
                                                PAB - Panamanian Balboa
                                            </option>
                                                                                                                                                                <option value="PEN" >
                                                PEN - Peruvian nuevo sol
                                            </option>
                                                                                                                                                                <option value="PGK" >
                                                PGK - Papua New Guinean Kina
                                            </option>
                                                                                                                                                                <option value="PHP" >
                                                PHP - Philippino Peso
                                            </option>
                                                                                                                                                                <option value="PKR" >
                                                PKR - Pakistani Rupee
                                            </option>
                                                                                                                                                                <option value="PLN" >
                                                PLN - Polish Zloty
                                            </option>
                                                                                                                                                                <option value="PYG" >
                                                PYG - Paraguayan Guaraní
                                            </option>
                                                                                                                                                                <option value="QAR" >
                                                QAR - Qatar Riyal
                                            </option>
                                                                                                                                                                <option value="RON" >
                                                RON - Romanian Leu
                                            </option>
                                                                                                                                                                <option value="RSD" >
                                                RSD - Serbian Dinar
                                            </option>
                                                                                                                                                                <option value="RUB" >
                                                RUB - Russian Rubles
                                            </option>
                                                                                                                                                                <option value="SAR" >
                                                SAR - Saudi Riyal
                                            </option>
                                                                                                                                                                <option value="SBD" >
                                                SBD - Solomon Islands Dollar
                                            </option>
                                                                                                                                                                <option value="SCR" >
                                                SCR - Seychellois Rupee
                                            </option>
                                                                                                                                                                <option value="SEK" >
                                                SEK - Swedish Krona
                                            </option>
                                                                                                                                                                <option value="SGD" >
                                                SGD - Singapore Dollar
                                            </option>
                                                                                                                                                                <option value="SVC" >
                                                SVC - Salvadoran Colón
                                            </option>
                                                                                                                                                                <option value="SYP" >
                                                SYP - Syrian Pound
                                            </option>
                                                                                                                                                                <option value="THB" >
                                                THB - Thailand Baht
                                            </option>
                                                                                                                                                                <option value="TND" >
                                                TND - Tunisian Dinar
                                            </option>
                                                                                                                                                                <option value="TOP" >
                                                TOP - Tongan Paʻanga
                                            </option>
                                                                                                                                                                <option value="TRY" >
                                                TRY - Turkish Lira
                                            </option>
                                                                                                                                                                <option value="TTD" >
                                                TTD - Trinidad & Tobago Dollar
                                            </option>
                                                                                                                                                                <option value="TWD" >
                                                TWD - New Taiwan Dollar
                                            </option>
                                                                                                                                                                <option value="UAH" >
                                                UAH - Ukrainian Grivna
                                            </option>
                                                                                                                                                                <option value="USD" >
                                                USD - United States Dollar
                                            </option>
                                                                                                                                                                <option value="UYU" >
                                                UYU - Uruguayan Peso
                                            </option>
                                                                                                                                                                <option value="VEF" >
                                                VEF - Venezuelan Bolívar
                                            </option>
                                                                                                                                                                <option value="VND" >
                                                VND - Vietnamese Dong
                                            </option>
                                                                                                                                                                <option value="VUV" >
                                                VUV - Vanuatu Vatu
                                            </option>
                                                                                                                                                                <option value="WST" >
                                                WST - Samoan tālā
                                            </option>
                                                                                                                                                                <option value="XCD" >
                                                XCD - East Caribbean Dollar
                                            </option>
                                                                                                                                                                <option value="XOF" >
                                                XOF - West African CFA Franc
                                            </option>
                                                                                                                                                                <option value="YER" >
                                                YER - Yemeni Rial
                                            </option>
                                                                                                                                                                <option value="ZAR" >
                                                ZAR - South African Rand
                                            </option>
                                                                                                            </select>

                                <noscript>
                                    <input aria-label="Go" type="submit" value="Go">
                                </noscript>
                            </div>

                            <div style="clear:both"></div>
                        </div>
                    
                                                                                                                                        
                    <div id="order__content">
                                                    <ul class="order__checkout">
                                <li id="order__cart__contents" class="order__products__listing">
                                                                        <div id="order__cart__contents" class="order__products__listing">
    <div class="order__box" style="">
    <div class="order__box__aux1">
        <div class="order__box__aux2">
                                                <div class="order__box__title">
                        <div class="order__box__aux1">
                            <div class="order__box__aux2">
                                Products in your shopping cart
                            </div>
                        </div>
                    </div>
                            
            <div class="order__box__content">
                <div class="order__box__aux1">
                    <div class="order__box__aux2">
                                <div id="order__products">
            <table width="95%" cellpadding="2" cellspacing="0" border="0" class="order__cart__products__table">
                <tr class="order__listing__header" valign="baseline">
                    <td class="order__listing__header__name">Product/Service name</td>
                    <td class="order__listing__header__delivery">Delivery</td>
                    <td class="order__listing__header__qty">Quantity</td>
                    <td class="order__listing__header__unit__price">Unit price</td>
                    <td class="order__listing__header__total__price">Value</td>
                    <td class="order__listing__header__remove">Remove</td>
                </tr>

                                                                
                                    <tr class="order__listing__row" id="order__listing__row__4551005">
                        <td class="order__listing__item__name  ">
                                                            Mobirise Site (Yearly)
                                                                                                                                    <div class="order__product__info">
                                        [1603740.mobirisesite.com]
                                    </div>
                                                                
                                
                                                                                    </td>
                        <td class="order__listing__item__delivery">
                                                                                                Electronic
                                                                                    </td>
                        <td class="order__listing__item__qty">
                                                                                                <input type="hidden" value="1" name="qty0" size='3' maxlength="4">1                                                                                    </td>
                        <td nowrap class="order__listing__item__unit__price">
                                                                                                                                
                                
                                R$ 268,99
                                                    </td>
                        <td nowrap class="order__listing__item__total__price">
                                                                                        
                            
                            R$ 268,99
                        </td>
                        <td align="right" class="order__listing__item__remove">
                                                            <input aria-label="Remove" type="checkbox" name="rmv0" value="4551005">
                                <input type="hidden" name="prod0" value="4551005">
                                                    </td>
                    </tr>

                    
                    
                                                                                                                                            </table>

                    </div>
        <div id="order__totals">
            <div>
                <table width="95%" border="0" cellpadding="2" cellspacing="0" class="order__checkout__summary">
                    
                    <tr>
                        <td align="right"><hr class="order__separator" noshade></td>
                    </tr>

                    <tr id="order__sub__total__row">
                        <td>
                                                                                        <div class="order__sub__total" id="order__sub__total__1">
                                    Subtotal:
                                                                            R$ 268,99                                                                    </div>

                                <div class="order__sub__total" id="order__sub__total__2">
                                    Total TAX/VAT
                                    :
                                                                            R$ 0,00                                                                    </div>
                                                        <div class="order__total " id="order__sub__total__3">
                                                                    Total price:
                                                                                                    R$ 268,99                                                            </div>
                                                        <div class="order__billing__currency__note" id="order__sub__total__4">
                                The billing currency is BRL (R$ )
                            </div>
                            <div style="clear:both"></div>
                        </td>
                    </tr>

                    <!-- download insurance service -->
                                        <!-- / download insurance service -->

                    <!-- backup CD option -->
                                        <!-- / backup CD option -->

                    <tr>
                        <td>
                            <div id="order__update__cart">
                                <input type="hidden" id="Update_hidden" value="true">
                                <input type="hidden" id="submit_type" name="submit_type">
                                <input aria-label="Update cart" type="button" class="order__button order__update__cart__button" name="Update" id="Update" value="Update cart" onclick="this.disabled=true;document.getElementById('submit_type').value='cross_selling';document.getElementById('Update_hidden').name=this.name;this.form.submit();">
                            </div>
                            <div id="order__coupon__input">
                                                                                                            Discount coupon:
                                                                        &nbsp;
                                    <input aria-label="Discount coupon" type="text" name="coupon" size="10" value="" class="order__text__field order__text__field__coupon" />                                                            </div>
                            
                            <div style="clear:both"></div>
                        </td>
                    </tr>

                    
                                            <tr>
                            <td class="textsmall" >
                                <div class="order__vat__note">
                                    The total price inclusive of applicable taxes will be displayed before the order is transmitted.
                                </div>

                                
                            </td>
                        </tr>
                                    </table>
            </div>

            <!-- CROSS SELLING -->
                        <!-- / CROSS SELLING -->
        </div>
    
                    </div>
                </div>
            </div>

            <div class="order__box__footer">
                <div class="order__box__aux1">
                    <div class="order__box__aux2">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    <input type="hidden" name="Update" value="true">
    <input type="hidden" id="Checkout_hidden" value="true">
</div>                                    <table width="100%" border="0" align="center" cellpadding="2" cellspacing="2">
                                        <tr>
                                            <td align="left"><a class="order__link order__homepage__link" href='http://vista-buttons.com/'>&lt; Back to shopping</a></td>
                                            <td align="right"> </td>
                                        </tr>
                                    </table>
                                </li>
                                                                                                            <li id="order__checkout__autofill__data">
                                            <div class="order__box" style="">
    <div class="order__box__aux1">
        <div class="order__box__aux2">
            
            <div class="order__box__content">
                <div class="order__box__aux1">
                    <div class="order__box__aux2">
                        <div class="paypal-express">
    <a href="#" id="paypal-express-btn" style="display: none; font-size: 0;">
                            <img src="../images/paypal/en-paypal-express.png" alt="Paypal Express Checkout" id="paypalImage" />
            </a>
        </div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const paymentMethods = {
            '#paypal-express-btn': 8,
            '#paypal-credit-express-btn': 83
        };
        Object.entries(paymentMethods).forEach(([selector, paymentMethod]) => {
            $(selector).show();

            $(document).on('click', selector, function (event) {
                const paymentRadio = $('#payment_radio_' + paymentMethod);
                if (paymentRadio.length === 1) {
                    paymentRadio.trigger('click');
                } else {
                    $('#payment').val(paymentMethod);
                }
                $('#checkoutSubmitBtn').trigger('click');

                event.preventDefault();
                return false;
            });
        });
    });
</script>


                    </div>
                </div>
            </div>

            <div class="order__box__footer">
                <div class="order__box__aux1">
                    <div class="order__box__aux2">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
                                        </li>
                                                                                                                <li id="order__checkout__payoptions__data">
                                            <div class="order__box" style="">
    <div class="order__box__aux1">
        <div class="order__box__aux2">
                                                <div class="order__box__title">
                        <div class="order__box__aux1">
                            <div class="order__box__aux2">
                                Payment Options
                            </div>
                        </div>
                    </div>
                            
            <div class="order__box__content">
                <div class="order__box__aux1">
                    <div class="order__box__aux2">
                                <table border="0" cellspacing="0" cellpadding="0" class="order__checkout__billing" id="order__checkout__billing__payoptions__table">
                <tr>
                        <td>
                                <table border="0" cellspacing="0" class="order__checkout__billing__content order__checkout__payment__content" cellpadding="0">

                                                                                
                                        	                                        
                                        
                                                                                                
                                                
                                                <tr id="payment_radios_wrap_tr">
                                                    <td colspan="2">

                                                        <table width="100%" cellspacing="0" cellpadding="0" border="0" class="payment_radios_table">
                                                            <tr>
                                                                <td width="50%">

                                                                    
                                                                    <div id="payment_radios_wrap">
                                                                                                                                                    <div aria-label="Visa/MasterCard" class="payment_radio_wrap ">
                                                                                <input type="radio" name="payment_radio" id="payment_radio_1" value="1" />
                                                                                <img src="/images/spacer.gif?20250630164206" class="sprite-icons-payments icon_payment_1" alt="Visa/MasterCard" />
                                                                                <label for="payment_radio_1">Visa/MasterCard</label>
                                                                            </div>
                                                                                                                                                    <div aria-label="American Express" class="payment_radio_wrap ">
                                                                                <input type="radio" name="payment_radio" id="payment_radio_4" value="4" />
                                                                                <img src="/images/spacer.gif?20250630164206" class="sprite-icons-payments icon_payment_4" alt="American Express" />
                                                                                <label for="payment_radio_4">American Express</label>
                                                                            </div>
                                                                                                                                                    <div aria-label="Discover" class="payment_radio_wrap ">
                                                                                <input type="radio" name="payment_radio" id="payment_radio_14" value="14" />
                                                                                <img src="/images/spacer.gif?20250630164206" class="sprite-icons-payments icon_payment_14" alt="Discover" />
                                                                                <label for="payment_radio_14">Discover</label>
                                                                            </div>
                                                                                                                                                    <div aria-label="UnionPay" class="payment_radio_wrap ">
                                                                                <input type="radio" name="payment_radio" id="payment_radio_56" value="56" />
                                                                                <img src="/images/spacer.gif?20250630164206" class="sprite-icons-payments icon_payment_56" alt="UnionPay" />
                                                                                <label for="payment_radio_56">UnionPay</label>
                                                                            </div>
                                                                                                                                                    <div aria-label="Bank transfer" class="payment_radio_wrap payment_radio_hidden">
                                                                                <input type="radio" name="payment_radio" id="payment_radio_2" value="2" />
                                                                                <img src="/images/spacer.gif?20250630164206" class="sprite-icons-payments icon_payment_2" alt="Bank transfer" />
                                                                                <label for="payment_radio_2">Bank transfer</label>
                                                                            </div>
                                                                                                                                                    <div aria-label="PayPal" class="payment_radio_wrap payment_radio_hidden">
                                                                                <input type="radio" name="payment_radio" id="payment_radio_8" value="8" />
                                                                                <img src="/images/spacer.gif?20250630164206" class="sprite-icons-payments icon_payment_8" alt="PayPal" />
                                                                                <label for="payment_radio_8">PayPal</label>
                                                                            </div>
                                                                                                                                                    <div aria-label="Purchase order" class="payment_radio_wrap payment_radio_hidden">
                                                                                <input type="radio" name="payment_radio" id="payment_radio_11" value="11" />
                                                                                <img src="/images/spacer.gif?20250630164206" class="sprite-icons-payments icon_payment_11" alt="Purchase order" />
                                                                                <label for="payment_radio_11">Purchase order</label>
                                                                            </div>
                                                                                                                                            </div>

                                                                </td>
                                                                <td width="50%">


                                                                    <div id="payment-options-secure-box">
                                                                        <div class="secure-title-wrap"><img src="/images/spacer.gif?20250630164206" class="sprite secure-lock-ico" alt="Secure Checkout"> <span class="secure-title">Secure Checkout</span></div>
                                                                        
                                                                        <div class="secure-description-wrap"><p>The whole ordering process is supported by 2Checkout (now Verifone), who handles all transaction data according to market security standards.</p></div>

                                                                        <div class="secure-description-logos">
                                                                            <img src="/images/cart/bbb-logo-h43.gif?20250630164206" alt="Accredited Business BBB" width="111" height="43" />
                                                                            <span class="pci_tooltip">
                                                                                <span class="pci_tooltip_label" tabindex="0">
                                                                                    <img src="/images/cart/pci-dss-logo-h43.gif?20250630164206" alt="Trust badge indicating certification to Payment Card Industry Data Security Standards." width="106" height="43"/>
                                                                                </span>
                                                                                <span class="pci_tooltip_text">
                                                                                    <div class="pci_tooltip_text_wrap">
                                                                                        <span class="pci_tooltip_content">Your payment will be processed in accordance with the latest Payment Card Industry Data Security Standards</span>
                                                                                    </div>
                                                                                </span>
                                                                            </span>
                                                                        </div>
                                                                    </div>

                                                                </td>
                                                            </tr>
                                                        </table>

                                                    </td>
                                                </tr>

                                                <tr id="payment__methods" class="DESIGN_TYPE_2">
                                                    <td colspan="2">

                                                        <select aria-label="Select payment method" name="payment" id="payment" onchange="FillSelectbox('billing_currency',this.options[this.options.selectedIndex].value); showMessage(this); ShowAdditionalSection(this.options[this.options.selectedIndex].value);">
                                                            <option value="1" selected="selected">Visa/MasterCard</option>
<option value="4">American Express</option>
<option value="14">Discover</option>
<option value="56">UnionPay</option>
<option value="2">Bank transfer</option>
<option value="8">PayPal</option>
<option value="11">Purchase order</option>

                                                        </select>

                                                    </td>
                                                </tr>

                                                

                                                

                                                <tr id="payment__methods__icons">
                                                                                                        <td align="right" colspan="2">
                                                                                                                <div class="order__payment__methods" id="order__payment__methods">
                                                                                                                                                <img alt="Visa/MasterCard"  src="/images/spacer.gif?20250630164206"
                                                                                                                                                                                        onclick="
                                                                                                        document.getElementById('payment').selectedIndex = 0;
                                                                                                        FillSelectbox('billing_currency',document.getElementById('payment').options[0].value);
                                                                                                        showMessage(document.getElementById('payment'));
                                                                                                        ShowAdditionalSection(document.getElementById('payment').options[0].value);
                                                                                                "
                                                                                        
                                                                                        title="Visa/MasterCard"
                                                                                        id="pay_opt_1"
                                                                                        class="sprite order__payment__option__button"
                                                                                ><img alt="American Express"  src="/images/spacer.gif?20250630164206"
                                                                                                                                                                                        onclick="
                                                                                                        document.getElementById('payment').selectedIndex = 1;
                                                                                                        FillSelectbox('billing_currency',document.getElementById('payment').options[1].value);
                                                                                                        showMessage(document.getElementById('payment'));
                                                                                                        ShowAdditionalSection(document.getElementById('payment').options[1].value);
                                                                                                "
                                                                                        
                                                                                        title="American Express"
                                                                                        id="pay_opt_4"
                                                                                        class="sprite order__payment__option__button"
                                                                                ><img alt="Discover"  src="/images/spacer.gif?20250630164206"
                                                                                                                                                                                        onclick="
                                                                                                        document.getElementById('payment').selectedIndex = 2;
                                                                                                        FillSelectbox('billing_currency',document.getElementById('payment').options[2].value);
                                                                                                        showMessage(document.getElementById('payment'));
                                                                                                        ShowAdditionalSection(document.getElementById('payment').options[2].value);
                                                                                                "
                                                                                        
                                                                                        title="Discover"
                                                                                        id="pay_opt_14"
                                                                                        class="sprite order__payment__option__button"
                                                                                ><img alt="UnionPay"  src="/images/spacer.gif?20250630164206"
                                                                                                                                                                                        onclick="
                                                                                                        document.getElementById('payment').selectedIndex = 3;
                                                                                                        FillSelectbox('billing_currency',document.getElementById('payment').options[3].value);
                                                                                                        showMessage(document.getElementById('payment'));
                                                                                                        ShowAdditionalSection(document.getElementById('payment').options[3].value);
                                                                                                "
                                                                                        
                                                                                        title="UnionPay"
                                                                                        id="pay_opt_56"
                                                                                        class="sprite order__payment__option__button"
                                                                                ><img alt="Bank transfer"  src="/images/spacer.gif?20250630164206"
                                                                                                                                                                                        onclick="
                                                                                                        document.getElementById('payment').selectedIndex = 4;
                                                                                                        FillSelectbox('billing_currency',document.getElementById('payment').options[4].value);
                                                                                                        showMessage(document.getElementById('payment'));
                                                                                                        ShowAdditionalSection(document.getElementById('payment').options[4].value);
                                                                                                "
                                                                                        
                                                                                        title="Bank transfer"
                                                                                        id="pay_opt_2"
                                                                                        class="sprite order__payment__option__button"
                                                                                ><img alt="PayPal"  src="/images/spacer.gif?20250630164206"
                                                                                                                                                                                        onclick="
                                                                                                        document.getElementById('payment').selectedIndex = 5;
                                                                                                        FillSelectbox('billing_currency',document.getElementById('payment').options[5].value);
                                                                                                        showMessage(document.getElementById('payment'));
                                                                                                        ShowAdditionalSection(document.getElementById('payment').options[5].value);
                                                                                                "
                                                                                        
                                                                                        title="PayPal"
                                                                                        id="pay_opt_8"
                                                                                        class="sprite order__payment__option__button"
                                                                                ><img alt="Purchase order"  src="/images/spacer.gif?20250630164206"
                                                                                                                                                                                        onclick="
                                                                                                        document.getElementById('payment').selectedIndex = 6;
                                                                                                        FillSelectbox('billing_currency',document.getElementById('payment').options[6].value);
                                                                                                        showMessage(document.getElementById('payment'));
                                                                                                        ShowAdditionalSection(document.getElementById('payment').options[6].value);
                                                                                                "
                                                                                        
                                                                                        title="Purchase order"
                                                                                        id="pay_opt_11"
                                                                                        class="sprite order__payment__option__button"
                                                                                >                                                                </div>
                                                        </td>
                                                </tr>

                                                                                                 
                                                
                                                                                                    <tr id="offline_payment_msg" style="display:none;">
                                                        <td colspan="2" class="order__payoption__note">
                                                            <span id="offline_payment_msg_span" class="note-paymethod"></span>
                                                        </td>
                                                    </tr>
                                                    <tr id="redirect_payment_msg" style="display:none;">
                                                        <td colspan="2" class="order__payoption__note">
                                                            <span id="redirect_payment_msg_span" class="note-paymethod"></span>
                                                        </td>
                                                    </tr>
                                                    <tr id="pay_option_boleto_msg" style="display:none;">
                                                        <td colspan="2" class="order__payoption__note">
                                                            <span id="pay_option_boleto_msg_span" class="note-paymethod">For Boleto Bancario, product delivery takes place only after payment is received in full.<br> 
Paying by credit card usually offers you immediate access to the products you ordered. <br>Your phone number is required to pay for your order with Boleto Bancario.</span>
                                                        </td>
                                                    </tr>
                                                

                                                <tr id="pay_option_po_msg" style="display:none;">
                                                        <td colspan="2" class="order__payoption__note">
                                                                                                                                        <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                                                                <tr>
                                                                                        <td width="48"><img src="/images/spacer.gif?20250630164206" class="sprite sprite-warning-ico" alt="Additional Information"></td>
                                                                                        <td><span class="note-paymethod">The order will be fulfilled before payment is made, in accordance with the Purchase Order document, signed and addressed to 2Checkout (now Verifone). Note that you can select the final payment method from a number of options including Bank/Wire transfer, credit cards or PayPal. Additional guidance will be available immediately after you place the order.</span></td>
                                                                                </tr>
                                                                        </table>
                                                                                                                        </td>
                                                </tr>
                                                <tr id="pay_option_dduk_fields" style="display:none;">
                                                    <td colspan="2">
                                                        <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                                            <tr>
                                                                <td colspan="2"><div class="order__separator" style="display: block;"></div></td>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="2" class="order__checkout__form__label">
                                                                    <span class="order__text__label order__checkout__form__mandatory order__text__label__mandatory ">
                                                                        Are you the account holder of a UK bank/building society account?*
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="2">
                                                                    <input aria-label="Yes" type="radio" id="pay_option_dduk_account_yes" name="dduk_account" value="yes" />
                                                                    <label for="pay_option_dduk_account_yes">Yes</label>
                                                                    <input aria-label="No" type="radio" id="pay_option_dduk_account_no" name="dduk_account" value="no" />
                                                                    <label for="pay_option_dduk_account_no">No</label>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="2" class="order__checkout__form__label" style="padding: 10px 0px 5px 0px;">
                                                                    <span class="order__text__label order__checkout__form__mandatory order__text__label__mandatory ">
                                                                        Are you authorized to debit this account?*
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="2" style="padding: 0px 0px 15px 0px;">
                                                                    <input aria-label="Yes" type="radio" id="pay_option_dduk_auth_yes" name="dduk_auth" value="yes" />
                                                                    <label for="pay_option_dduk_auth_yes">Yes</label>
                                                                    <input aria-label="No" type="radio" id="pay_option_dduk_auth_no" name="dduk_auth" value="no" />
                                                                    <label for="pay_option_dduk_auth_no">No</label>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                                                                                    <tr class="order__text__field" id="boleto_fiscal_code_fields" style="display:none;">
                                                        <td class="order__checkout__form__label">
                                                            <span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory  ">Fiscal Code (CPF)*:</span>
                                                        </td>
                                                        <td class="order__checkout__form__input">
                                                            <input aria-label="Fiscal Code (CPF)" id="boleto_fiscal_code" type="text" name="boleto_fiscal_code" value="" class="order__text__field order__text__field__mandatory " maxlength="30" size="40" autocomplete="off" />
                                                        </td>
                                                    </tr>
                                                
                                                <tr id="pay_option_dduk_msg" style="display:none;">
                                                    <td colspan="2" class="order__payoption__note">
                                                        <span class="note-paymethod">All the normal Direct Debit safeguards and guarantees apply. No changes in the amount, date or frequency to be debited can be made without notifying
you at least 10 working days in advance of your account being debited. In
the event of any error, you are entitled to an immediate refund from your bank. You have the right to cancel a Direct Debit Instruction at any time simply by writing to your bank or building society, with a copy to us.</span>
                                                    </td>
                                                </tr>

                                                                                    

                                                                        </table>

                                                             <!--  -->
                                    <div id="order__autorenewal__container" class="checkout " >
                                        <input aria-label="Enable auto-renewal for this order" type="checkbox" name="autorenewal" id="order__autorenewal" value="1" >
                                            <input type="hidden" name="order-autorenewal-is-submitted" value="1" />    
                                                    <span class="tooltip">
                                                        <span class="tooltip_label" tabindex="0"><label for="order__autorenewal" id="order__autorenewal__text">Enable auto-renewal for this order</label> <img alt="Enable auto-renewal for this order"  src="/images/spacer.gif?20250630164206" class="sprite help_icon help_icon_tooltip" /></span>
                                                        <span class="tooltip_text">
                                                            <div class="tooltip_text_wrap">
                                                            <span class="tooltip_title"><img src="/images/spacer.gif?20250630164206" alt="Details" class="sprite help_icon_tooltip_popup" /> Details</span>
                                                            <span class="tooltip_content"><p>By enabling automatic billing, your subscription will be automatically renewed before it expires, avoiding usage interruptions in a highly secure environment.</p><p>You can disable the auto-renewal option at any time.</p>
                                                                                                                        </span>
                                                            </div>
                                                        </span>
                                                    </span>

                                    </div>
                                

                                                       
                        
                        </td>
                </tr>
        </table>
<!-- 268.99 BRL -->


                    </div>
                </div>
            </div>

            <div class="order__box__footer">
                <div class="order__box__aux1">
                    <div class="order__box__aux2">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
                                        </li>
                                    
                                    <li id="order__checkout__billing__data">
                                        <div class="order__box" style="">
    <div class="order__box__aux1">
        <div class="order__box__aux2">
                                                <div class="order__box__title">
                        <div class="order__box__aux1">
                            <div class="order__box__aux2">
                                Billing Information
                            </div>
                        </div>
                    </div>
                            
            <div class="order__box__content">
                <div class="order__box__aux1">
                    <div class="order__box__aux2">
                            <table border="0" cellspacing="0" cellpadding="0" class="order__checkout__billing" id="order__checkout__billing__info__table">
        <tbody id="order__checkout__billing__info__tbody">
            <tr>
                <td>
                    <span class="order__help_billing">
                        Fields marked with * are required.&nbsp;To avoid delays and cancellations, please double-check the data!&nbsp;&nbsp;(<a href="Javascript:void(0);" onClick="openJsPopup('help.php?CART_ID=448f9aa180c57616de7927eb0715cf2c', '', 650, 'auto', 'ui-dialog-help');return false;">Help</a>)
                    </span>
                    <hr noshade class="order__separator">
                    <table border="0" cellspacing="0" class="order__checkout__billing__content" cellpadding="0">
                        <tbody id="order__checkout__billing__info__content__tbody">
                                                            <tr id="bill_fullname">
                                    <td class="order__checkout__form__label first-col">
                                        <span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory ">
                                            Full name*:
                                        </span>
                                    </td>
                                    <td>
                                        <input aria-label="Full name" type="text" name="fullname" id="fullname" value=""  class="order__text__field order__text__field__mandatory " />
                                    </td>
                                </tr>
                            
                            <tr id="bill_first_name" style="display:none;">
                                <td class="order__checkout__form__label first-col" nowrap>
                                    <span class="order__text__label  ">
                                        First name*:
                                    </span>
                                </td>
                                <td class="order__checkout__form__input">
                                    <input aria-label="First name" name="fname" type="text" id="fname" value="" size="40" maxlength="40" class="order__text__field  ">
                                </td>
                            </tr>

                            <tr id="bill_last_name" style="display:none;">
                                <td class="order__checkout__form__label" nowrap>
                                    <span class="order__text__label  ">
                                        Last name*:
                                    </span>
                                </td>
                                <td class="order__checkout__form__input">
                                    <input aria-label="Last name" name="lname" type="text" id="lname" value="" size="40" maxlength="40" class="order__text__field  ">
                                </td>
                            </tr>

                            <tr id="bill_address1" style="display:none;">
                                <td class="order__checkout__form__label" nowrap>
                                    <span class="order__text__label order__checkout__form__mandatory order__text__label__mandatory ">
                                        Address*:
                                    </span>
                                </td>
                                <td class="order__checkout__form__input">
                                    <input aria-label="Address" name="address" type="text" id="address" size="40" maxlength="100" value="" class="order__text__field order__text__field__mandatory " />
                                </td>
                            </tr>

                            <tr id="bill_address2" style="display:none;">
                                <td class="order__checkout__form__label"></td>
                                <td class="order__checkout__form__input"><input aria-label="Address 2" name="address2" type="text" id="address2" size="40" maxlength="100" value="" class="order__text__field" /></td>
                            </tr>

                            <tr id="bill_city" class="SHORT_FORM">
                                <td class="order__checkout__form__label" nowrap>
                                    <span class="order__text__label order__checkout__form__mandatory order__text__label__mandatory ">
                                        City*:
                                    </span>
                                </td>
                                <td class="order__checkout__form__input">
                                    <input aria-label="City"
                                        name="city"
                                        type="text"
                                        id="city"
                                        size="40"
                                        maxlength="30"
                                        value=""
                                        class="order__text__field order__text__field__mandatory "
                                     />
                                </td>
                            </tr>

                            <tr id="bill_zip" >
                                <td class="order__checkout__form__label" nowrap>
                                    <span class="order__text__label order__checkout__form__mandatory order__text__label__mandatory ">
                                        Zip or postal code<span id="bill_zip__mandatory">*</span>:
                                    </span>
                                </td>
                                <td class="order__checkout__form__input">
                                    <input aria-label="Zip or postal code" name="zipcode" type="text" id="zipcode" size="25" maxlength="20" value="" class="order__text__field order__text__field__mandatory " />
                                </td>
                            </tr>

                            <tr id="bill_country">
                                <td class="order__checkout__form__label" nowrap>
                                    <span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory ">
                                        Country*:
                                    </span>
                                </td>
                                <td class="order__checkout__form__input">
                                    <div class="select_box">
                                        <select aria-label="Country" name="billingcountry" id="billingcountry" onChange="ShowExtraFields(this.options[this.options.selectedIndex].value);" class="order__select__field order__select__field__mandatory ">
                                                                                                                                        <option value="" >Please select...</option>
                                            
                                                                                                                                            <option value="240" >Afghanistan</option>
                                                                                                                                            <option value="1" >Albania</option>
                                                                                                                                            <option value="2" >Algeria</option>
                                                                                                                                            <option value="3" >American Samoa</option>
                                                                                                                                            <option value="4" >Andorra</option>
                                                                                                                                            <option value="5" >Angola</option>
                                                                                                                                            <option value="6" >Anguilla</option>
                                                                                                                                            <option value="7" >Antarctica</option>
                                                                                                                                            <option value="8" >Antigua and Barbuda</option>
                                                                                                                                            <option value="9" >Argentina</option>
                                                                                                                                            <option value="10" >Armenia</option>
                                                                                                                                            <option value="11" >Aruba</option>
                                                                                                                                            <option value="12" >Australia</option>
                                                                                                                                            <option value="13" >Austria</option>
                                                                                                                                            <option value="14" >Azerbaijan</option>
                                                                                                                                            <option value="15" >Bahamas, The</option>
                                                                                                                                            <option value="16" >Bahrain</option>
                                                                                                                                            <option value="17" >Bangladesh</option>
                                                                                                                                            <option value="18" >Barbados</option>
                                                                                                                                            <option value="19" >Belarus</option>
                                                                                                                                            <option value="20" >Belgium</option>
                                                                                                                                            <option value="21" >Belize</option>
                                                                                                                                            <option value="22" >Benin</option>
                                                                                                                                            <option value="23" >Bermuda</option>
                                                                                                                                            <option value="24" >Bhutan</option>
                                                                                                                                            <option value="25" >Bolivia</option>
                                                                                                                                            <option value="26" >Bosnia and Herzegovina</option>
                                                                                                                                            <option value="27" >Botswana</option>
                                                                                                                                            <option value="28" >Bouvet Island</option>
                                                                                                                                            <option value="29" selected>Brazil</option>
                                                                                                                                            <option value="30" >British Indian Ocean Territory</option>
                                                                                                                                            <option value="32" >Brunei</option>
                                                                                                                                            <option value="33" >Bulgaria</option>
                                                                                                                                            <option value="34" >Burkina Faso</option>
                                                                                                                                            <option value="35" >Burundi</option>
                                                                                                                                            <option value="37" >Cambodia</option>
                                                                                                                                            <option value="38" >Cameroon</option>
                                                                                                                                            <option value="39" >Canada</option>
                                                                                                                                            <option value="241" >Canary Islands</option>
                                                                                                                                            <option value="40" >Cape Verde</option>
                                                                                                                                            <option value="41" >Cayman Islands</option>
                                                                                                                                            <option value="42" >Central African Republic</option>
                                                                                                                                            <option value="43" >Chad</option>
                                                                                                                                            <option value="44" >Chile</option>
                                                                                                                                            <option value="45" >China</option>
                                                                                                                                            <option value="46" >Christmas Island</option>
                                                                                                                                            <option value="47" >Cocos (Keeling) Islands</option>
                                                                                                                                            <option value="48" >Colombia</option>
                                                                                                                                            <option value="49" >Comoros</option>
                                                                                                                                            <option value="50" >Congo</option>
                                                                                                                                            <option value="51" >Cook Islands</option>
                                                                                                                                            <option value="52" >Costa Rica</option>
                                                                                                                                            <option value="53" >Croatia</option>
                                                                                                                                            <option value="55" >Cyprus</option>
                                                                                                                                            <option value="56" >Czech Republic</option>
                                                                                                                                            <option value="234" >Democratic Republic of the Congo</option>
                                                                                                                                            <option value="57" >Denmark</option>
                                                                                                                                            <option value="58" >Djibouti</option>
                                                                                                                                            <option value="59" >Dominica</option>
                                                                                                                                            <option value="60" >Dominican Republic</option>
                                                                                                                                            <option value="61" >East Timor</option>
                                                                                                                                            <option value="62" >Ecuador</option>
                                                                                                                                            <option value="63" >Egypt</option>
                                                                                                                                            <option value="64" >El Salvador</option>
                                                                                                                                            <option value="65" >Equatorial Guinea</option>
                                                                                                                                            <option value="66" >Eritrea</option>
                                                                                                                                            <option value="67" >Estonia</option>
                                                                                                                                            <option value="200" >Eswatini</option>
                                                                                                                                            <option value="68" >Ethiopia</option>
                                                                                                                                            <option value="69" >Falkland Islands (Malvinas)</option>
                                                                                                                                            <option value="70" >Faroe Islands</option>
                                                                                                                                            <option value="71" >Fiji</option>
                                                                                                                                            <option value="72" >Finland</option>
                                                                                                                                            <option value="73" >France</option>
                                                                                                                                            <option value="75" >French Guiana</option>
                                                                                                                                            <option value="76" >French Polynesia</option>
                                                                                                                                            <option value="77" >French Southern/Antarctic Lands</option>
                                                                                                                                            <option value="78" >Gabon</option>
                                                                                                                                            <option value="79" >Gambia</option>
                                                                                                                                            <option value="80" >Georgia</option>
                                                                                                                                            <option value="81" >Germany</option>
                                                                                                                                            <option value="82" >Ghana</option>
                                                                                                                                            <option value="83" >Gibraltar</option>
                                                                                                                                            <option value="84" >Greece</option>
                                                                                                                                            <option value="85" >Greenland</option>
                                                                                                                                            <option value="86" >Grenada</option>
                                                                                                                                            <option value="87" >Guadeloupe</option>
                                                                                                                                            <option value="88" >Guam</option>
                                                                                                                                            <option value="89" >Guatemala</option>
                                                                                                                                            <option value="90" >Guinea</option>
                                                                                                                                            <option value="91" >Guinea-Bissau</option>
                                                                                                                                            <option value="92" >Guyana</option>
                                                                                                                                            <option value="93" >Haiti</option>
                                                                                                                                            <option value="94" >Heard and McDonald Islands</option>
                                                                                                                                            <option value="95" >Honduras</option>
                                                                                                                                            <option value="96" >Hong Kong</option>
                                                                                                                                            <option value="97" >Hungary</option>
                                                                                                                                            <option value="98" >Iceland</option>
                                                                                                                                            <option value="99" >India</option>
                                                                                                                                            <option value="100" >Indonesia</option>
                                                                                                                                            <option value="101" >Iraq</option>
                                                                                                                                            <option value="102" >Ireland</option>
                                                                                                                                            <option value="104" >Israel</option>
                                                                                                                                            <option value="105" >Italy</option>
                                                                                                                                            <option value="36" >Ivory Coast</option>
                                                                                                                                            <option value="106" >Jamaica</option>
                                                                                                                                            <option value="107" >Japan</option>
                                                                                                                                            <option value="245" >Jersey</option>
                                                                                                                                            <option value="108" >Jordan</option>
                                                                                                                                            <option value="109" >Kazakhstan</option>
                                                                                                                                            <option value="110" >Kenya</option>
                                                                                                                                            <option value="111" >Kiribati</option>
                                                                                                                                            <option value="113" >Korea, South</option>
                                                                                                                                            <option value="114" >Kuwait</option>
                                                                                                                                            <option value="115" >Kyrgyzstan</option>
                                                                                                                                            <option value="116" >Lao Peoples Democratic Republic</option>
                                                                                                                                            <option value="117" >Latvia</option>
                                                                                                                                            <option value="118" >Lebanon</option>
                                                                                                                                            <option value="119" >Lesotho</option>
                                                                                                                                            <option value="120" >Liberia</option>
                                                                                                                                            <option value="122" >Liechtenstein</option>
                                                                                                                                            <option value="123" >Lithuania</option>
                                                                                                                                            <option value="124" >Luxembourg</option>
                                                                                                                                            <option value="125" >Macau</option>
                                                                                                                                            <option value="239" >Macedonia</option>
                                                                                                                                            <option value="126" >Madagascar</option>
                                                                                                                                            <option value="127" >Malawi</option>
                                                                                                                                            <option value="128" >Malaysia</option>
                                                                                                                                            <option value="129" >Maldives</option>
                                                                                                                                            <option value="130" >Mali</option>
                                                                                                                                            <option value="131" >Malta</option>
                                                                                                                                            <option value="238" >Man, Isle of</option>
                                                                                                                                            <option value="132" >Marshall Islands</option>
                                                                                                                                            <option value="133" >Martinique</option>
                                                                                                                                            <option value="134" >Mauritania</option>
                                                                                                                                            <option value="135" >Mauritius</option>
                                                                                                                                            <option value="136" >Mayotte</option>
                                                                                                                                            <option value="137" >Mexico</option>
                                                                                                                                            <option value="138" >Micronesia</option>
                                                                                                                                            <option value="139" >Moldova, Republic of</option>
                                                                                                                                            <option value="140" >Monaco</option>
                                                                                                                                            <option value="141" >Mongolia</option>
                                                                                                                                            <option value="142" >Montserrat</option>
                                                                                                                                            <option value="143" >Morocco</option>
                                                                                                                                            <option value="144" >Mozambique</option>
                                                                                                                                            <option value="145" >Myanmar (Burma)</option>
                                                                                                                                            <option value="146" >Namibia</option>
                                                                                                                                            <option value="147" >Nauru</option>
                                                                                                                                            <option value="148" >Nepal</option>
                                                                                                                                            <option value="150" >Netherlands</option>
                                                                                                                                            <option value="151" >New Caledonia</option>
                                                                                                                                            <option value="152" >New Zealand</option>
                                                                                                                                            <option value="153" >Nicaragua</option>
                                                                                                                                            <option value="154" >Niger</option>
                                                                                                                                            <option value="155" >Nigeria</option>
                                                                                                                                            <option value="156" >Niue</option>
                                                                                                                                            <option value="157" >Norfolk Island</option>
                                                                                                                                            <option value="158" >Northern Mariana Islands</option>
                                                                                                                                            <option value="159" >Norway</option>
                                                                                                                                            <option value="160" >Oman</option>
                                                                                                                                            <option value="161" >Pakistan</option>
                                                                                                                                            <option value="162" >Palau</option>
                                                                                                                                            <option value="163" >Panama</option>
                                                                                                                                            <option value="164" >Papua New Guinea</option>
                                                                                                                                            <option value="165" >Paraguay</option>
                                                                                                                                            <option value="166" >Peru</option>
                                                                                                                                            <option value="167" >Philippines</option>
                                                                                                                                            <option value="168" >Pitcairn</option>
                                                                                                                                            <option value="169" >Poland</option>
                                                                                                                                            <option value="170" >Portugal</option>
                                                                                                                                            <option value="171" >Puerto Rico</option>
                                                                                                                                            <option value="172" >Qatar</option>
                                                                                                                                            <option value="173" >Reunion</option>
                                                                                                                                            <option value="237" >Romania</option>
                                                                                                                                            <option value="174" >Russia</option>
                                                                                                                                            <option value="175" >Rwanda</option>
                                                                                                                                            <option value="176" >Saint Lucia</option>
                                                                                                                                            <option value="177" >Samoa</option>
                                                                                                                                            <option value="178" >San Marino</option>
                                                                                                                                            <option value="179" >Sao Tome and Principe</option>
                                                                                                                                            <option value="180" >Saudi Arabia</option>
                                                                                                                                            <option value="181" >Senegal</option>
                                                                                                                                            <option value="242" >Serbia</option>
                                                                                                                                            <option value="182" >Seychelles</option>
                                                                                                                                            <option value="183" >Sierra Leone</option>
                                                                                                                                            <option value="184" >Singapore</option>
                                                                                                                                            <option value="249" >Sint Maarten</option>
                                                                                                                                            <option value="185" >Slovakia</option>
                                                                                                                                            <option value="186" >Slovenia</option>
                                                                                                                                            <option value="187" >Solomon Islands</option>
                                                                                                                                            <option value="188" >Somalia</option>
                                                                                                                                            <option value="189" >South Africa</option>
                                                                                                                                            <option value="190" >South Georgia/Sandwich Islands</option>
                                                                                                                                            <option value="191" >Spain</option>
                                                                                                                                            <option value="192" >Sri Lanka</option>
                                                                                                                                            <option value="193" >St. Helena</option>
                                                                                                                                            <option value="194" >St. Kitts and Nevis</option>
                                                                                                                                            <option value="195" >St. Pierre and Miquelon</option>
                                                                                                                                            <option value="196" >St. Vincent and the Grenadines</option>
                                                                                                                                            <option value="198" >Suriname</option>
                                                                                                                                            <option value="199" >Svalbard/Jan Mayen Islands</option>
                                                                                                                                            <option value="201" >Sweden</option>
                                                                                                                                            <option value="202" >Switzerland</option>
                                                                                                                                            <option value="204" >Taiwan</option>
                                                                                                                                            <option value="205" >Tajikistan</option>
                                                                                                                                            <option value="206" >Tanzania, United Republic of</option>
                                                                                                                                            <option value="207" >Thailand</option>
                                                                                                                                            <option value="208" >Togo</option>
                                                                                                                                            <option value="209" >Tokelau</option>
                                                                                                                                            <option value="210" >Tonga</option>
                                                                                                                                            <option value="211" >Trinidad and Tobago</option>
                                                                                                                                            <option value="212" >Tunisia</option>
                                                                                                                                            <option value="213" >Turkey</option>
                                                                                                                                            <option value="214" >Turkmenistan</option>
                                                                                                                                            <option value="215" >Turks and Caicos Islands</option>
                                                                                                                                            <option value="216" >Tuvalu</option>
                                                                                                                                            <option value="221" >U.S. Minor Outlying Islands</option>
                                                                                                                                            <option value="217" >Uganda</option>
                                                                                                                                            <option value="218" >Ukraine</option>
                                                                                                                                            <option value="219" >United Arab Emirates</option>
                                                                                                                                            <option value="220" >United Kingdom</option>
                                                                                                                                            <option value="222" >United States of America</option>
                                                                                                                                            <option value="224" >Uruguay</option>
                                                                                                                                            <option value="225" >Uzbekistan</option>
                                                                                                                                            <option value="226" >Vanuatu</option>
                                                                                                                                            <option value="227" >Vatican City State (Holy See)</option>
                                                                                                                                            <option value="228" >Venezuela</option>
                                                                                                                                            <option value="229" >Vietnam</option>
                                                                                                                                            <option value="223" >Virgin Islands</option>
                                                                                                                                            <option value="31" >Virgin Islands (British)</option>
                                                                                                                                            <option value="230" >Wallis and Futuna Islands</option>
                                                                                                                                            <option value="231" >Western Sahara</option>
                                                                                                                                            <option value="232" >Yemen</option>
                                                                                                                                            <option value="235" >Zambia</option>
                                                                                                                                            <option value="236" >Zimbabwe</option>
                                                                                    </select>
                                    </div>
                                    <input type='hidden' name='stateis'>
                                </td>
                            </tr>

                            <tr id="statedrop">
                                <td class="order__checkout__form__label" nowrap>
                                    <span id="req_state_label" class="order__text__label  ">
                                        State or province:
                                    </span>
                                </td>
                                <td class="order__checkout__form__input">
                                    <div class="select_box">
                                        <select aria-label="State or province" name="state" id="state" class="order__select__field " >
                                            <option value=''>----------- None -----------</option>
                                            <option></option>
                                            <option></option>
                                            <option></option>
                                            <option></option>
                                        </select>
                                    </div>
                                </td>
                            </tr>

                            <tr id="stateedit" style="display: none;" class="">
                                <td class="order__checkout__form__label"  nowrap>
                                    <span id="req_state_label_text" class="order__text__label  ">
                                        State or province:
                                    </span>
                                </td>
                                <td class="order__checkout__form__input">
                                    <input aria-label="State or province" name="state2" id="state2" value="S&atilde;o Paulo" class="order__text__field " type="text" />
                                </td>
                            </tr>

                            <tr class="order__separator__row">
                                <td colspan="2"><hr noshade class="order__separator"></td>
                            </tr>

                            <tr id="bill_company">
                                <td class="order__checkout__form__label" nowrap id="td1_company" err_company="0" err_company_po="0">
                                    <span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory " id="comp_mandatory" style="display:none;">
                                        Company Name*:
                                    </span>
                                    <span id="comp_optional" class="order__text__label">Company Name:</span>
                                </td>
                                <td class="order__checkout__form__input" id="td2_company">
                                    <input aria-label="Company Name" name="company" type="text" id="company" value="" size="40" maxlength="50" class="order__text__field " />
                                </td>
                            </tr>

                            <tr style="display: none;" id="rnumber">
                                <td nowrap class="order__checkout__form__label">
                                    <span class="order__text__label">Trade Register:</span>
                                </td>
                                <td class="order__checkout__form__input">
                                    <input aria-label="Trade Register" name="regnumber" type="text" id="regnumber" size="40" maxlength="50" value="" class="order__text__field" />
                                </td>
                            </tr>

                            <tr id="nfcode" class="order__checkout__form__national__fiscal__code " style="display: ">
                                <td class="order__checkout__form__label" nowrap>
                                <span class="order__text__label ">
                                VAT ID:
                                </span>
                                </td>
                                <td class="order__checkout__form__input">
                                <input aria-label="VAT ID" name="nationalid" type="text" id="nationalid" size="40" maxlength="50" onblur= "validateVatId(this.value,'billingcountry', true)" value="" class="order__text__field " />
                                </td>
                            </tr>

                            <tr id="nfcode_text">
                                <td></td>
                                <td class="note" id="nat_info">
                                <span class="order__text__label" style="display:none" id="nat_error">Your National ID number could not be validated. Please try again later.</span>
                                </td>
                            </tr>

                            <tr id="fcode" class="order__checkout__form__fiscal__code ">
                                <td class="order__checkout__form__label" nowrap>
                                    <span class="order__text__label ">
                                        VAT ID:
                                    </span>
                                </td>
                                <td class="order__checkout__form__input">
                                    <input aria-label="VAT ID" name="fiscalcode" type="text" id="fiscalcode" size="40" maxlength="50" onblur= "validateVatId(this.value,'billingcountry')" value="" class="order__text__field " />
                                                                            (<a href="Javascript:void(0);" tabindex="0" onClick="openJsPopup('help.php?countryId='+$('#billingcountry').val()+'&id=6&CART_ID=448f9aa180c57616de7927eb0715cf2c', '', 650, 'auto');return false;">Details</a>)
                                                                    </td>
                            </tr>


                            <tr id="fcode_text">
                                <td></td>
                                <td class="note" id="vat_info">
                                                                    (only for European Union VAT-registered customers, if available)
                                                                    <span class="order__text__label" style="display:none" id="vat_error">Your VAT number could not be validated. Please try again later.</span>
                                </td>
                            </tr>

                            <tr id="taxofficeTr" class="order__checkout__form__tax__office" style="display: none">
                                <td class="order__checkout__form__label" nowrap>
                                <span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory ">
                                Tax office*:
                                </span>
                                </td>
                                <td class="order__checkout__form__input">
                                <input aria-label="Tax office" name="taxoffice" type="text" id="taxoffice" size="40" maxlength="50" value="" class="order__text__field order__text__field__mandatory " />
                                </td>
                            </tr>

                            <tr style="display: none;" id="cbank">
                                <td class="order__checkout__form__label" nowrap>
                                    <span class="order__text__label ">Bank:</span>
                                </td>
                                <td class="order__checkout__form__input">
                                    <input aria-label="Bank" name="bank" type="text" id="bank" size="40" maxlength="40" value="" class="order__text__field " />
                                </td>
                            </tr>

                            <tr style="display: none;" id="cbankaccount">
                                <td class="order__checkout__form__label" nowrap>
                                    <span class="order__text__label ">Bank Account:</span>
                                </td>
                                <td class="order__checkout__form__label">
                                    <input aria-label="Bank Account" name="bankaccount" type="text" id="bankaccount" size="40" maxlength="50" value="" class="order__text__field " />
                                </td>
                            </tr>

                            <tr class="order__separator__row">
                                <td colspan="2"><hr noshade class="order__separator"></td>
                            </tr>

                            <tr id="bill_phone" style="display:none;">
                                <td class="order__checkout__form__label" nowrap>
                                    <span id="order__phone" class="order__text__label  ">
                                        Phone number<span id="order__phone__mandatory" style="display:none;">*</span>:
                                    </span>
                                </td>
                                <td class="order__checkout__form__input" nowrap>
                                    <input aria-label="Phone number" name="phone" type="text" id="phone" size="40" maxlength="40" value="" class="order__text__field  " />
                                </td>
                            </tr>
                            <tr id="bill_phone_info" style="display:none;">
                                <td></td>
                                <td class="note">(the phone number you have provided will be used only if you cannot be reached via email.)</td>
                            </tr>

                            <tr id="bill_fax">
                                <td class="order__checkout__form__label" nowrap>
                                    <span class="order__text__label">Fax number:</span>
                                </td>
                                <td class="order__checkout__form__input">
                                    <input aria-label="Fax number" name="fax" type="text" id="fax" size="40" maxlength="40" value="" class="order__text__field" />
                                </td>
                            </tr>

                            <tr class="order__empty__row">
                                <td colspan="2"></td>
                            </tr>

                            <tr id="bill_email">
                                <td class="order__checkout__form__label" nowrap>
                                    <span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory ">
                                        Email*:
                                    </span>
                                </td>
                                <td class="order__checkout__form__input">
                                    <input aria-label="Email" name="email" type="text" id="email" size="40" maxlength="80" value="" class="order__text__field order__text__field__mandatory " />

                                    <span class="tooltip_gdpr hidden" id="order_bill_email_info_tooltip">
                                        <span class="tooltip_label_gdpr" tabindex="0">
                                            <img alt="By filling in your personal data you agree that 2Checkout (now Verifone), its affiliates and partners can use it for order related communications." src="/images/spacer.gif?20250630164206" class="help_icon_tooltip_gdpr">
                                        </span>
                                        <div class="tooltip_text_gdpr">
                                            <span class="tooltip_content_gdpr">By filling in your personal data you agree that 2Checkout (now Verifone), its affiliates and partners can use it for order related communications.</span>
                                        </div>
                                    </span>

                                </td>
                            </tr>

                            <tr id="bill_email_verify" style="display:none;">
                                <td class="order__checkout__form__label" >
                                    <span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory ">
                                        Confirm email*:
                                    </span>
                                </td>
                                <td class="order__checkout__form__input">
                                    <input aria-label="Confirm email" name="re_email" type="text" id="re_email" class="order__text__field order__text__field__mandatory " value="" size="40" maxlength="80" AUTOCOMPLETE=OFF />
                                </td>
                            </tr>

                            
                            <tr class="order__empty__row">
                                <td colspan="2">&nbsp;</td>
                            </tr>
                                                            <tr>
                                    <td colspan="2"><input type="hidden" name="samedelivery" id="samedelivery" value="Yes"></td>
                                </tr>
                                                                                    <tr class="order__empty__row">
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>

                                                                                        <tbody id="credit__cart__fields__container">

                <tr class="card__data__form">
            <td>
                <div class="secure-title-wrap"><img src="/images/spacer.gif?20250630164206" class="sprite secure-lock-ico" alt="SECURE CHECKOUT" /> <span class="secure-title">SECURE CHECKOUT</span></div>
            </td>
            <td>
                <div class="secure-title-line"></div>
            </td>
        </tr>
        
        <tr class="order__separator__row">
                <td colspan="2"><hr noshade class="order__separator"></td>
        </tr>

        
                <tr id="order__checkout__form__billing__currency" class="order__checkout__form__billing__currencies">
        <td class="order__checkout__form__label">
        <span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory  ">Billing currency*:</span></td>
        <td>
            <select aria-label="Billing currency" name="billing_currency" id="billing_currency" class="order__select__field order__select__field__mandatory ">
                <option value="BRL" selected="selected">BRL - Brazilian Real</option>

            </select>
        </td>
</tr>

        <tr id="order__checkout__form__po_internal_number_text" class="order__checkout__form__po_internal_number_text" style="display:none;">
        <td colspan="2" class="order__po_internal_number__note">
        	<span class="order__text__label">Enter your internal purchase order number for this order below. The identifier will be included in your Purchase Order form and invoice.</span>
        </td>      
</tr>
<tr id="order__checkout__form__po_internal_number" class="order__checkout__form__po_internal_number" style="display:none;">
        <td class="order__checkout__form__label" nowrap>
        <span class="order__text__label">Internal PO Number:</span></td>
       <td class="order__checkout__form__input">
	   		<input aria-label="Internal PO Number" name="shopper_reference_number" type="text" id="shopper_reference_number" size="40" maxlength="50" value="" class="order__text__field" />
	   </td>
</tr>         

        <tr class="order__text__field" id="data__brazilian_cpf_cnpj" style="display:none;">
            <td class="order__checkout__form__label"><span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory  ">Fiscal Code (CPF)*:</span></td>
            <td class="order__checkout__form__input">
                <input aria-label="Fiscal Code (CPF)" id="brazilian_cpf_cnpj" type="text" name="brazilian_cpf_cnpj" value="" class="order__text__field order__text__field__mandatory " maxlength="30" size="40" autocomplete="off" />
            </td>
        </tr>

        <tr class="card__data__form" id="card__data__nr">
            <td class="order__checkout__form__label"><span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory  ">Card number*:</span></td>
            <td class="order__checkout__form__input">
                <input aria-label="Card number" id="tiCNumber"
						 data-card_type_element="#payment"						type="text" name="ccnumber" value="" 						class="order__text__field order__text__field__mandatory  creditcard_validate"
						maxlength="30" size="40" autocomplete="off" onFocus="custCare();" onBlur="custCareST(document.getElementById('cCare'));"
						/>
				<span id="paymentoption_icon"></span>
            </td>
        </tr>

                    <tr id="data__installments" style="display:none;">

    <td class="order__checkout__form__label">
        <span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory 
             
                    ">
            Installments:
        </span>
    </td>
    
    <td class="order__checkout__form__input">
                    <select name="installments" id="installments" 
                                class="order__select__field 
                     
                                ">
                        </select>
                        
            </td>

</tr>        
        <tr class="card__data__form" id="card__data__types">
            <td class="order__checkout__form__label"><span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory ">Card type*:</span></td>
            <td  class="order__checkout__form__input">
                <select aria-label="Card type" name="cardtype" id="cbCardType" class="order__select__field order__select__field__mandatory">
                                            <option value="-1">Please select ...</option>
                                                                <option value="visa" >Visa</option>
                                            <option value="mastercard" >MasterCard</option>
                                            <option value="visaelectron" >Visa Electron</option>
                                            <option value="maestro" >Maestro</option>
                                    </select>
            </td>
        </tr>

        <tr class="card__data__form" id="card__data__expdates">
                <td class="order__checkout__form__label"><span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory  ">Card expiration date*:</span></td>
                <td class="order__checkout__form__input">

                <select aria-label="Month" id="cbExpMounth" name="ccexpmonth" class="order__select__field order__select__field__mandatory " autocomplete="off">
                <option value="">Month</option>
                                                                                                                <option value="01" >
                                                01 (January)
                                        </option>
                                                                                                                <option value="02" >
                                                02 (February)
                                        </option>
                                                                                                                <option value="03" >
                                                03 (March)
                                        </option>
                                                                                                                <option value="04" >
                                                04 (April)
                                        </option>
                                                                                                                <option value="05" >
                                                05 (May)
                                        </option>
                                                                                                                <option value="06" >
                                                06 (June)
                                        </option>
                                                                                                                <option value="07" >
                                                07 (July)
                                        </option>
                                                                                                                <option value="08" >
                                                08 (August)
                                        </option>
                                                                                                                <option value="09" >
                                                09 (September)
                                        </option>
                                                                                                                <option value="10" >
                                                10 (October)
                                        </option>
                                                                                                                <option value="11" >
                                                11 (November)
                                        </option>
                                                                                                                <option value="12" >
                                                12 (December)
                                        </option>
                                                        </select>
                        <select aria-label="Year" name="ccexpyear" id="cbExpYear" class="order__select__field order__select__field__mandatory " autocomplete="off">
                                <option value="">Year</option>
                                                                        <option value="2025"  >
                                                2025
                                        </option>
                                                                        <option value="2026"  >
                                                2026
                                        </option>
                                                                        <option value="2027"  >
                                                2027
                                        </option>
                                                                        <option value="2028"  >
                                                2028
                                        </option>
                                                                        <option value="2029"  >
                                                2029
                                        </option>
                                                                        <option value="2030"  >
                                                2030
                                        </option>
                                                                        <option value="2031"  >
                                                2031
                                        </option>
                                                                        <option value="2032"  >
                                                2032
                                        </option>
                                                                        <option value="2033"  >
                                                2033
                                        </option>
                                                                        <option value="2034"  >
                                                2034
                                        </option>
                                                                        <option value="2035"  >
                                                2035
                                        </option>
                                                                        <option value="2036"  >
                                                2036
                                        </option>
                                                                        <option value="2037"  >
                                                2037
                                        </option>
                                                                        <option value="2038"  >
                                                2038
                                        </option>
                                                                        <option value="2039"  >
                                                2039
                                        </option>
                                                                        <option value="2040"  >
                                                2040
                                        </option>
                                                                        <option value="2041"  >
                                                2041
                                        </option>
                                                                        <option value="2042"  >
                                                2042
                                        </option>
                                                                        <option value="2043"  >
                                                2043
                                        </option>
                                                                        <option value="2044"  >
                                                2044
                                        </option>
                                                                        <option value="2045"  >
                                                2045
                                        </option>
                                                                        <option value="2046"  >
                                                2046
                                        </option>
                                                                        <option value="2047"  >
                                                2047
                                        </option>
                                                                        <option value="2048"  >
                                                2048
                                        </option>
                                                                        <option value="2049"  >
                                                2049
                                        </option>
                                                                        <option value="2050"  >
                                                2050
                                        </option>
                                                                        <option value="2051"  >
                                                2051
                                        </option>
                                                                        <option value="2052"  >
                                                2052
                                        </option>
                                                                        <option value="2053"  >
                                                2053
                                        </option>
                                                                        <option value="2054"  >
                                                2054
                                        </option>
                                                                        <option value="2055"  >
                                                2055
                                        </option>
                                                        </select>
                </td>
        </tr>

        <tr class="card__data__form" id="card__data__cvvc">
                <td class="order__checkout__form__label">
                <span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory  ">
                Security code*:
                </span>
                </td>
                <td class="order__checkout__form__input">
                <input aria-label="Security code" id="tiCVV" type="text" name="cvv2" size="5" maxlength="5" value="" class="order__text__field order__text__field__mandatory " autocomplete="off"  /></td>
        </tr>

        <tr class="card__data__form" id="card__data__fullname">
                <td class="order__checkout__form__label"><span class="order__checkout__form__mandatory nameOnCard order__text__label order__text__label__mandatory  ">Card holder name*:</span></td>
                <td class="order__checkout__form__input">
                <input aria-label="Card holder name" name="nameoncard" size="40" type="text" id="nameoncard" value="" class="nameOnCard order__text__field order__text__field__mandatory " autocomplete="off" onFocus="custCare();" onBlur="custCareST(document.getElementById('cCareName'));" />
                <input type="hidden" name="cCare" id="cCare" value="0">
                <input type="hidden" name="cCareName" id="cCareName" value="0">
                </td>
        </tr>

            <tr id="data__bank_issuer" style="display:none;">
    <td colspan="2" id="data__bank_issuer__wrap" class="align-center">
        <table width="100%">
            <tr>
                <td class="order__checkout__form__label">
                    <span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory 
                         
                                            ">
                        Select your bank*:
                    </span>
                </td>
            </tr>
            <tr>
                <td class="order__checkout__form__input">
                    <div class="order__checkout__form__input__logos__wrap">
                                                                                                                                                                        <div class="order__checkout__form__input__logo order__checkout__form__input__logo_abn_amro 
                                "
                                     title="ABN AMRO"
                                     data-logo-label="ABN AMRO"
                                     data-logo-label-slug="abn_amro"
                                     data-logo-id="ABNANL2A">
                                </div>
                                                                                                                                                <div class="order__checkout__form__input__logo order__checkout__form__input__logo_ing 
                                "
                                     title="ING"
                                     data-logo-label="ING"
                                     data-logo-label-slug="ing"
                                     data-logo-id="INGBNL2A">
                                </div>
                                                                                                                                                <div class="order__checkout__form__input__logo order__checkout__form__input__logo_sns_bank 
                                "
                                     title="SNS Bank"
                                     data-logo-label="SNS Bank"
                                     data-logo-label-slug="sns_bank"
                                     data-logo-id="SNSBNL2A">
                                </div>
                                                                                                                                                <div class="order__checkout__form__input__logo order__checkout__form__input__logo_van_lanschot 
                                "
                                     title="Van Lanschot"
                                     data-logo-label="Van Lanschot"
                                     data-logo-label-slug="van_lanschot"
                                     data-logo-id="FVLBNL22">
                                </div>
                                                                                                                                                <div class="order__checkout__form__input__logo order__checkout__form__input__logo_triodos_bank 
                                "
                                     title="Triodos Bank"
                                     data-logo-label="Triodos Bank"
                                     data-logo-label-slug="triodos_bank"
                                     data-logo-id="TRIONL2U">
                                </div>
                                                                                                                                                <div class="order__checkout__form__input__logo order__checkout__form__input__logo_knab 
                                "
                                     title="Knab"
                                     data-logo-label="Knab"
                                     data-logo-label-slug="knab"
                                     data-logo-id="KNABNL2H">
                                </div>
                                                                                                                                                <div class="order__checkout__form__input__logo order__checkout__form__input__logo_rabobank 
                                "
                                     title="Rabobank"
                                     data-logo-label="Rabobank"
                                     data-logo-label-slug="rabobank"
                                     data-logo-id="RABONL2U">
                                </div>
                                                                                                                                                <div class="order__checkout__form__input__logo order__checkout__form__input__logo_sns_regio_bank 
                                "
                                     title="SNS Regio Bank"
                                     data-logo-label="SNS Regio Bank"
                                     data-logo-label-slug="sns_regio_bank"
                                     data-logo-id="RBRBNL21">
                                </div>
                                                                                                                                                <div class="order__checkout__form__input__logo order__checkout__form__input__logo_asn_bank 
                                "
                                     title="ASN Bank"
                                     data-logo-label="ASN Bank"
                                     data-logo-label-slug="asn_bank"
                                     data-logo-id="ASNBNL21">
                                </div>
                                                                                                                                                <div class="order__checkout__form__input__logo order__checkout__form__input__logo_bunq 
                                "
                                     title="Bunq"
                                     data-logo-label="Bunq"
                                     data-logo-label-slug="bunq"
                                     data-logo-id="BUNQNL2A">
                                </div>
                                                                        </div>
                </td>
            </tr>
            <tr>
                <td class="order__checkout__form__input">
                                            <select name="bank_issuer" id="bank_issuer" 
                            autocomplete="off"                            class="order__select__field 
                                order__select__field__mandatory 
                                                        ">
                                                    <option value="" selected="selected">
                            Please select...
                            </option>
                                                    <option value="ABNANL2A" >
                            ABN AMRO
                            </option>
                                                    <option value="INGBNL2A" >
                            ING
                            </option>
                                                    <option value="SNSBNL2A" >
                            SNS Bank
                            </option>
                                                    <option value="FVLBNL22" >
                            Van Lanschot
                            </option>
                                                    <option value="TRIONL2U" >
                            Triodos Bank
                            </option>
                                                    <option value="KNABNL2H" >
                            Knab
                            </option>
                                                    <option value="RABONL2U" >
                            Rabobank
                            </option>
                                                    <option value="RBRBNL21" >
                            SNS Regio Bank
                            </option>
                                                    <option value="ASNBNL21" >
                            ASN Bank
                            </option>
                                                    <option value="BUNQNL2A" >
                            Bunq
                            </option>
                                                </select>
                                        
                                    </td>
            </tr>
        </table>
    </td>
</tr>    <style>
    #data__bank_issuer .order__checkout__form__label {
        text-align:center;
        padding:10px;
    }
    
    #data__bank_issuer .order__checkout__form__input {
        text-align:center;
    }
    
    #bank_issuer { float:none; }
    
    #data__bank_issuer .order__checkout__form__input__logos__wrap {
        margin: 0 auto;
        max-width: 550px;
    }

    #data__bank_issuer .order__checkout__form__input__logo {
        float:left;
        width: 90px;
        height: 33px;
        margin:10px 10px;
        background:url('/images/order/iDeal-banks-sprite.png?20250630164206') 0 0 no-repeat;
        cursor: pointer;
    }

    #data__bank_issuer .order__checkout__form__input__logo_abn_amro {
        background-position: 0 0;
    }
    #data__bank_issuer .order__checkout__form__input__logo_abn_amro.order__checkout__form__input__logo__selected {
        background-position: -90px 0px;
    }

    #data__bank_issuer .order__checkout__form__input__logo_asn_bank {
        background-position: 0 -33px;
    }
    #data__bank_issuer .order__checkout__form__input__logo_asn_bank.order__checkout__form__input__logo__selected {
        background-position: -90px -33px;
    }

    #data__bank_issuer .order__checkout__form__input__logo_friesland_bank {
        background-position: 0 -66px;
    }
    #data__bank_issuer .order__checkout__form__input__logo_friesland_bank.order__checkout__form__input__logo__selected {
        background-position: -90px -66px;
    }

    #data__bank_issuer .order__checkout__form__input__logo_ing {
        background-position: 0 -99px;
    }
    #data__bank_issuer .order__checkout__form__input__logo_ing.order__checkout__form__input__logo__selected {
        background-position: -90px -99px;
    }

    #data__bank_issuer .order__checkout__form__input__logo_knab {
        background-position: 0 -132px;
    }
    #data__bank_issuer .order__checkout__form__input__logo_knab.order__checkout__form__input__logo__selected {
        background-position: -90px -132px;
    }

    #data__bank_issuer .order__checkout__form__input__logo_rabobank {
        background-position: 0 -165px;
    }
    #data__bank_issuer .order__checkout__form__input__logo_rabobank.order__checkout__form__input__logo__selected {
        background-position: -90px -165px;
    }

    #data__bank_issuer .order__checkout__form__input__logo_sns_regio_bank {
        background-position: 0 -198px;
    }
    #data__bank_issuer .order__checkout__form__input__logo_sns_regio_bank.order__checkout__form__input__logo__selected {
        background-position: -90px -198px;
    }

    #data__bank_issuer .order__checkout__form__input__logo_sns_bank {
        background-position: 0 -231px;
    }
    #data__bank_issuer .order__checkout__form__input__logo_sns_bank.order__checkout__form__input__logo__selected {
        background-position: -90px -231px;
    }

    #data__bank_issuer .order__checkout__form__input__logo_triodos_bank {
        background-position: 0 -264px;
    }
    #data__bank_issuer .order__checkout__form__input__logo_triodos_bank.order__checkout__form__input__logo__selected {
        background-position: -90px -264px;
    }

    #data__bank_issuer .order__checkout__form__input__logo_van_lanschot {
        background-position: 0 -297px;
    }
    #data__bank_issuer .order__checkout__form__input__logo_van_lanschot.order__checkout__form__input__logo__selected {
        background-position: -90px -297px;
    }

    #data__bank_issuer .order__checkout__form__input__logo_bunq {
        background-position: 0 -330px;
    }
    #data__bank_issuer .order__checkout__form__input__logo_bunq.order__checkout__form__input__logo__selected {
        background-position: -90px -330px;
    }
    #data__bank_issuer .order__checkout__form__input__logo_handelsbanken {
        background-position: 0 -363px;
    }
    #data__bank_issuer .order__checkout__form__input__logo_handelsbanken.order__checkout__form__input__logo__selected {
        background-position: -90px -363px;
    }
    #data__bank_issuer .order__checkout__form__input__logo_moneyou {
        background-position: 0 -396px;
    }
    #data__bank_issuer .order__checkout__form__input__logo_moneyou.order__checkout__form__input__logo__selected {
        background-position: -90px -396px;
    }
</style>
<tr id="data__netbanking_bank_issuer" style="display:none;">
    <td colspan="2" id="data__netbanking_bank_issuer__wrap" class="align-center">
        <table width="100%">
            <tr>
                <td class="custom-select-cell order__checkout__form__label">
                    <span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory
                                                                    ">
                        Select your bank*:
                    </span>
                </td>
            </tr>

            <tr>
                <td class="custom-select-cell order__checkout__form__input">
                    <div class="avangate-custom-select">
                        <div class="search">
                            <input type="text" id="search-input" data-old="" placeholder="Please select..." readonly
                                   class="order__select__field
                                order__select__field__mandatory                                                            "
                                   autocomplete="off"
                            ><span></span>
                        </div>

                        <ul>
                                                            <li data-id="" data-name="Please select..." class="selected">
<!--                                    -->
                                    <span>Please select...</span>
                                </li>
                                                            <li data-id="CSMSNB" data-name="Cosmos Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Cosmos Bank</span>
                                </li>
                                                            <li data-id="CABB" data-name="Canara Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Canara Bank</span>
                                </li>
                                                            <li data-id="INDB" data-name="Indian Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Indian Bank</span>
                                </li>
                                                            <li data-id="SRSWT" data-name="Saraswat Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Saraswat Bank</span>
                                </li>
                                                            <li data-id="SOIB" data-name="South Indian Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>South Indian Bank</span>
                                </li>
                                                            <li data-id="UNIB" data-name="PNB (Erstwhile-United Bank of India)" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>PNB (Erstwhile-United Bank of India)</span>
                                </li>
                                                            <li data-id="OBCB" data-name="PNB (Erstwhile -Oriental Bank of Commerce)" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>PNB (Erstwhile -Oriental Bank of Commerce)</span>
                                </li>
                                                            <li data-id="HDFB" data-name="HDFC Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>HDFC Bank</span>
                                </li>
                                                            <li data-id="INOB" data-name="Indian Overseas Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Indian Overseas Bank</span>
                                </li>
                                                            <li data-id="PNBB" data-name="Punjab National Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Punjab National Bank</span>
                                </li>
                                                            <li data-id="INIB" data-name="IndusInd Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>IndusInd Bank</span>
                                </li>
                                                            <li data-id="FEDB" data-name="Federal Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Federal Bank</span>
                                </li>
                                                            <li data-id="KRKB" data-name="Karnataka Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Karnataka Bank</span>
                                </li>
                                                            <li data-id="SYNDB" data-name="Canara Bank (Erstwhile - Syndicate Bank)" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Canara Bank (Erstwhile - Syndicate Bank)</span>
                                </li>
                                                            <li data-id="TMBB" data-name="Tamilnad Mercantile Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Tamilnad Mercantile Bank</span>
                                </li>
                                                            <li data-id="DCBB" data-name="DCB Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>DCB Bank</span>
                                </li>
                                                            <li data-id="162B" data-name="Kotak Mahindra Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Kotak Mahindra Bank</span>
                                </li>
                                                            <li data-id="CSBN" data-name="Catholic Syrian Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Catholic Syrian Bank</span>
                                </li>
                                                            <li data-id="CBIB" data-name="Central Bank Of India" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Central Bank Of India</span>
                                </li>
                                                            <li data-id="JAKB" data-name="Jammu &amp; Kashmir Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Jammu &amp; Kashmir Bank</span>
                                </li>
                                                            <li data-id="KRVB" data-name="Karur Vysya Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Karur Vysya Bank</span>
                                </li>
                                                            <li data-id="RBLNB" data-name="RBL Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>RBL Bank</span>
                                </li>
                                                            <li data-id="JSBNB" data-name="Janata Sahakari Bank Pune" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Janata Sahakari Bank Pune</span>
                                </li>
                                                            <li data-id="DLSB" data-name="Dhanlaxmi Bank - Retail" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Dhanlaxmi Bank - Retail</span>
                                </li>
                                                            <li data-id="BOIB" data-name="Bank of India" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Bank of India</span>
                                </li>
                                                            <li data-id="IDBB" data-name="IDBI Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>IDBI Bank</span>
                                </li>
                                                            <li data-id="IDFCNB" data-name="IDFC FIRST Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>IDFC FIRST Bank</span>
                                </li>
                                                            <li data-id="BOMB" data-name="Bank of Maharashtra" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Bank of Maharashtra</span>
                                </li>
                                                            <li data-id="CPNB" data-name="Punjab National Bank - Corporate Banking" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Punjab National Bank - Corporate Banking</span>
                                </li>
                                                            <li data-id="UCOB" data-name="UCO Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>UCO Bank</span>
                                </li>
                                                            <li data-id="SVCNB" data-name="SVC Co-operative Bank Ltd." >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>SVC Co-operative Bank Ltd.</span>
                                </li>
                                                            <li data-id="KRVBC" data-name="Karur Vysya - Corporate Banking" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Karur Vysya - Corporate Banking</span>
                                </li>
                                                            <li data-id="JANANB" data-name="Jana Small Finance Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Jana Small Finance Bank</span>
                                </li>
                                                            <li data-id="AIRNB" data-name="Airtel Payments Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Airtel Payments Bank</span>
                                </li>
                                                            <li data-id="YESB" data-name="Yes Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Yes Bank</span>
                                </li>
                                                            <li data-id="AUSFCNB" data-name="AU Small Finance Bank - Corporate" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>AU Small Finance Bank - Corporate</span>
                                </li>
                                                            <li data-id="IDBICORP" data-name="IDBI Corp Netbanking" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>IDBI Corp Netbanking</span>
                                </li>
                                                            <li data-id="CSFBR" data-name="Capital Small Finance Bank Retail" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Capital Small Finance Bank Retail</span>
                                </li>
                                                            <li data-id="BANDNB" data-name="Bandhan Bank" >
<!--                                    <img src="https://via.placeholder.com/90x32">-->
                                    <span>Bandhan Bank</span>
                                </li>
                                                    </ul>

                        <input type="hidden" id="select-value" name="netbanking_bank_issuer" >
                    </div>
                </td>
            </tr>
        </table>
    </td>
</tr>
<style>
    .avangate-custom-select div.search {
        display:inline-block;
        margin: 0;
        padding: 0;
    }

    .avangate-custom-select input#search-input {
        height: 22px;
        padding: 0 5px;
        float: initial;
    }

    .avangate-custom-select input#search-input:hover {
        cursor:default;
    }

    .avangate-custom-select input#search-input:focus {
        cursor:initial;
    }

    .avangate-custom-select input#search-input+span::after {
        content: "\25BC";
        color: #989898;
        font-size: 12px;
        margin-left: -20px;
        pointer-events: none;
    }

    .avangate-custom-select input#search-input::placeholder {
        color: #000;
        opacity: 1;
    }

    .avangate-custom-select ul {
        padding: 0;
        margin: 0;
        display: none;
        background-color: #FFFFC5;
        color: #000;
        border: 1px solid #B7B7B7;
        border-top: 0px;
        position: absolute;
        max-height: 200px;
        overflow-y: auto;
        overflow-x: hidden;
        -webkit-box-shadow: inset 0px 4px 4px -5px #000000;
        box-shadow: inset 0px 4px 4px -5px #000000;

        -webkit-touch-callout: none; /* iOS Safari */
        -webkit-user-select: none; /* Safari */
        -khtml-user-select: none; /* Konqueror HTML */
        -moz-user-select: none; /* Old versions of Firefox */
        -ms-user-select: none; /* Internet Explorer/Edge */
        user-select: none; /* Non-prefixed version, currently */
    }

    .avangate-custom-select ul>li {
        list-style-type: none;
        padding: 5px 10px;
        text-align: left;
        display: flex;
        align-items: center;
    }

    .avangate-custom-select ul>li img {
        vertical-align: middle;
        margin-right: 5px;
        float: left;
    }

    .avangate-custom-select ul>li:hover {
        list-style-type: none;
        background-color: #1E90FF;
    }

    .avangate-custom-select ul>li.selected {
        list-style-type: none;
        background-color: #1E90FF;
    }
</style>

    <tr id="data__account_holder_first_name" style="display:none;">

    <td class="order__checkout__form__label">
        <span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory 
             
                    ">
            First name*:
        </span>
    </td>
    
    <td class="order__checkout__form__input">
                    <input type="text" id="account_holder_first_name" name="account_holder_first_name" value="" 
                maxlength="30"                autocomplete="off"                class="order__text__field 
                    order__text__field__mandatory 
                    "
                                            />
                        
                    <span class="tooltip" style="margin:5px 0 0 5px;">
                <span class="tooltip_label" tabindex="0"><img src="/images/spacer.gif?20250630164206" class="sprite help_icon help_icon_tooltip" alt="Help" /></span>
                <span class="tooltip_text">
                    <div class="tooltip_text_wrap">                                          
                      <span class="tooltip_content">The Bank Account Holder as it appears on the account. Please check that the Bank account is suitable to accept Direct Debits, as some accounts are unsuitable to operate Direct Debits.</span>
                    </div>
                </span>
              </span>
            </td>

</tr>    <tr id="data__account_holder_last_name" style="display:none;">

    <td class="order__checkout__form__label">
        <span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory 
             
                    ">
            Last name*:
        </span>
    </td>
    
    <td class="order__checkout__form__input">
                    <input type="text" id="account_holder_last_name" name="account_holder_last_name" value="" 
                maxlength="30"                autocomplete="off"                class="order__text__field 
                    order__text__field__mandatory 
                    "
                                            />
                        
                    <span class="tooltip" style="margin:5px 0 0 5px;">
                <span class="tooltip_label" tabindex="0"><img src="/images/spacer.gif?20250630164206" class="sprite help_icon help_icon_tooltip" alt="Help" /></span>
                <span class="tooltip_text">
                    <div class="tooltip_text_wrap">                                          
                      <span class="tooltip_content">The Bank Account Holder as it appears on the account. Please check that the Bank account is suitable to accept Direct Debits, as some accounts are unsuitable to operate Direct Debits.</span>
                    </div>
                </span>
              </span>
            </td>

</tr>



        
        
        <tr id="data__bank_account_number" style="display:none;">

    <td class="order__checkout__form__label">
        <span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory 
             
                    ">
            IBAN*:
        </span>
    </td>
    
    <td class="order__checkout__form__input">
                    <input type="text" id="bank_account_number" name="bank_account_number" value="" 
                                autocomplete="off"                class="order__text__field 
                    order__text__field__mandatory 
                    "
                                            />
                        
                    <span class="tooltip" style="margin:5px 0 0 5px;">
                <span class="tooltip_label" tabindex="0"><img src="/images/spacer.gif?20250630164206" class="sprite help_icon help_icon_tooltip" alt="Help" /></span>
                <span class="tooltip_text">
                    <div class="tooltip_text_wrap">                                          
                      <span class="tooltip_content">International Bank Account Number including the two-letter country code, the two check digits and the remaining alphanumeric characters of the basic bank account number (BBAN) as listed on the bank statement.</span>
                    </div>
                </span>
              </span>
            </td>

</tr>
    <tr id="data__qiwi_phone" style="display:none;">

    <td class="order__checkout__form__label">
        <span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory 
             
                    ">
            Your QIWI account mobile phone number*:
        </span>
    </td>
    
    <td class="order__checkout__form__input">
                    <input type="text" id="qiwi_phone" name="qiwi_phone" value="" 
                maxlength="30"                autocomplete="off"                class="order__text__field 
                    order__text__field__mandatory 
                    "
                                            />
                        
                    <span class="tooltip" style="margin:5px 0 0 5px;">
                <span class="tooltip_label" tabindex="0"><img src="/images/spacer.gif?20250630164206" class="sprite help_icon help_icon_tooltip" alt="Help" /></span>
                <span class="tooltip_text">
                    <div class="tooltip_text_wrap">                                          
                      <span class="tooltip_content">+71234567890 (+ country code, phone number)</span>
                    </div>
                </span>
              </span>
            </td>

</tr>    <tr id="data__ach_account_holder_name" style="display:none;">

    <td class="order__checkout__form__label">
        <span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory 
             
                    ">
            Account holder name*:
        </span>
    </td>
    
    <td class="order__checkout__form__input">
                    <input type="text" id="ach_account_holder_name" name="ach_account_holder_name" value="" 
                maxlength="30"                autocomplete="off"                class="order__text__field 
                    order__text__field__mandatory 
                    "
                                            />
                        
                    <span class="tooltip" style="margin:5px 0 0 5px;">
                <span class="tooltip_label" tabindex="0"><img src="/images/spacer.gif?20250630164206" class="sprite help_icon help_icon_tooltip" alt="Help" /></span>
                <span class="tooltip_text">
                    <div class="tooltip_text_wrap">                                          
                      <span class="tooltip_content">Name of the account holder must be entered in English or any other Latin character-based language.</span>
                    </div>
                </span>
              </span>
            </td>

</tr>    <tr id="data__ach_bank_routing_number" style="display:none;">

    <td class="order__checkout__form__label">
        <span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory 
             
                    ">
            Bank routing number*:
        </span>
    </td>
    
    <td class="order__checkout__form__input">
                    <input type="text" id="ach_bank_routing_number" name="ach_bank_routing_number" value="" 
                maxlength="30"                autocomplete="off"                class="order__text__field 
                    order__text__field__mandatory 
                    "
                                            />
                        
                    <span class="tooltip" style="margin:5px 0 0 5px;">
                <span class="tooltip_label" tabindex="0"><img src="/images/spacer.gif?20250630164206" class="sprite help_icon help_icon_tooltip" alt="Help" /></span>
                <span class="tooltip_text">
                    <div class="tooltip_text_wrap">                                          
                      <span class="tooltip_content">Bank routing number</span>
                    </div>
                </span>
              </span>
            </td>

</tr>    <tr id="data__ach_bank_account_number" style="display:none;">

    <td class="order__checkout__form__label">
        <span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory 
             
                    ">
            Account number*:
        </span>
    </td>
    
    <td class="order__checkout__form__input">
                    <input type="text" id="ach_bank_account_number" name="ach_bank_account_number" value="" 
                maxlength="30"                autocomplete="off"                class="order__text__field 
                    order__text__field__mandatory 
                    "
                 onFocus="custCare();"                 onBlur="custCareST(document.getElementById(&#039;cCareACH&#039;));"            />
                <input type="hidden" name="cCareACH" id="cCareACH" value="0">        
                    <span class="tooltip" style="margin:5px 0 0 5px;">
                <span class="tooltip_label" tabindex="0"><img src="/images/spacer.gif?20250630164206" class="sprite help_icon help_icon_tooltip" alt="Help" /></span>
                <span class="tooltip_text">
                    <div class="tooltip_text_wrap">                                          
                      <span class="tooltip_content">Your checking account number.</span>
                    </div>
                </span>
              </span>
            </td>

</tr>    <tr id="data__ach_bank_account_type" style="display:none;">

    <td class="order__checkout__form__label">
        <span class="order__checkout__form__mandatory order__text__label order__text__label__mandatory 
             
                    ">
            Account type*:
        </span>
    </td>
    
    <td class="order__checkout__form__input">
                    <select name="ach_bank_account_type" id="ach_bank_account_type" 
                autocomplete="off"                class="order__select__field 
                    order__select__field__mandatory 
                                ">
                            <option value="C" >
                Checking
                </option>
                            <option value="S" >
                Savings
                </option>
                        </select>
                        
                    <span class="tooltip" style="margin:5px 0 0 5px;">
                <span class="tooltip_label" tabindex="0"><img src="/images/spacer.gif?20250630164206" class="sprite help_icon help_icon_tooltip" alt="Help" /></span>
                <span class="tooltip_text">
                    <div class="tooltip_text_wrap">                                          
                      <span class="tooltip_content">Account type</span>
                    </div>
                </span>
              </span>
            </td>

</tr>    </tbody>



                                                    
                    </table>
                </td>
            </tr>
        </tbody>
    </table>

                    </div>
                </div>
            </div>

            <div class="order__box__footer">
                <div class="order__box__aux1">
                    <div class="order__box__aux2">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
                                    </li>

                                    
                                    
                                    <li>
                                        
                                                                                    <div class="order__checkout__button__container">
                                                                                                    <div id="place_order_terms_and_conditions" style="display:none;">
                                                        <div class="order__finish__terms__and__conds__agreement">
                                                            <br />
                                                                <div id="order__common__terms__and__conditions">By placing this order you agree to the <a href='https://www.2co.com/terms.html?MOR=active' target='_blank'>Terms and Conditions</a>.</div>
    <div id="order__gdpr__terms__and__conditions">By completing my purchase I confirm that I am over 16 years of age and I agree to the <a href='https://www.2co.com/terms.html?MOR=active' target='_blank'>Terms and Conditions</a>.</div>
                                                                <br /><br />
                                                        </div>
                                                    </div>
                                                    <input aria-label="Continue" type="submit" id="checkoutSubmitBtn" name="Submit" value="Continue" class="order__button order__finish__button order__finish__button__checkout order__finish__button__checkcart" />
                                                                                                                                            </div>
                                                                            </li>
                                
                                <li id="order__checkout__footer__data">
                                    <div id="order__checkout__footer">
                                                                                                                        <div class="order__box" style="">
    <div class="order__box__aux1">
        <div class="order__box__aux2">
            
            <div class="order__box__content">
                <div class="order__box__aux1">
                    <div class="order__box__aux2">
                         	<div id="order__statement">

            
	    	</div>
	

	<h3 class="order__finish__message__title">Need assistance?</h3>

<div id="order__statement__support">
	<p class="order__statement__support_1">Check out our <a href="https://secure.avangate.com/support/?merchant=DELUXMEN&template=Mobirise+3-column+popular+2024&lang=en" target="_blank">Customer Support</a> for more information on online payment related issues, order status and transactions.</p><br> <p class="order__statement__support_2">For prompt service, please state the order number from your confirmation email as a reference. We are happy to answer any questions you might have on the ordering process.</p>
</div>


    <div id="order__statement__hotline__information">
	<span class="order__statement__label">
		Hotline:
	</span>

        <span class="order__statement__value">
		                                                &lrm;+55 1131972046 (Brazil)
                    <br>
                                    &lrm;+31 88 000 0008 (International)
                    <br>
                            		            (24/7 English phone support for online payment related issues.)
	</span>
    </div>

	<div id="order__secure__seal"> &nbsp; </div>

	<div id="order__processedby">
	<!--NG_ORDER_PROCESSED_BY_AVANGATE-->
		Order processed by <b>2Checkout</b>, authorized reseller and merchant of the products and services offered within this store.
        <span id="business_company_details">Verifone Payments BV dba 2Checkout | [Mail address: P.O. Box 11334, 1001 GH Amsterdam] Singel 250, 4th floor, 1016AB, Amsterdam, Netherlands</span>
	</div>

    <div id="order__privacy">
                    <a href="https://www.2co.com/privacy.html?MOR=active" target="_blank">Privacy Policy</a>&nbsp;|
                            <a href="https://www.2co.com/terms.html?MOR=active" target="_blank">Terms and Conditions</a>&nbsp;|
                            <a href="https://www.2co.com/refund.html?MOR=active" target="_blank">Refund Policy</a>&nbsp;|                            <a href="https://www.2co.com/right-of-withdrawal.html" target="_blank">Right of withdrawal</a>
            </div>


                    </div>
                </div>
            </div>

            <div class="order__box__footer">
                <div class="order__box__aux1">
                    <div class="order__box__aux2">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
                                    </div>
                                </li>
                            </ul>
                                            </div>
                </div>
            </td>
        </tr>
    </table>
    <img src="/images/order/loading_circular1_48px.gif?20250630164206" alt="Loading" style="display:none;" />
</form>

<script language="Javascript" type="text/javascript">
    var omniture_vars = {"SESSION_START":1,"FIRST_CART_ACCESS":1,"SHOPPER_PREFILL_CREDIT_CARD_DATA":false,"DISCOUNT_COUPON":"active","PAYMENT_DETAILS_NEEDED":true,"HAS_RENEWAL_OPTION":1,"CART_TYPE":2,"REVIEW":"NO","TEST_ORDER":false,"CART_OPTIONS":{"PRE_FILLED_ORDER":null,"DISABLE_IN_CONTEXT":0,"CARD":2,"DESIGN_TYPE":2,"AUTO_PREFILL":0,"SHORT_FORM":true,"CART":1,"DOTEST":false},"DESIGN_TYPE":2,"SELLER_PACKAGES":{"FREE_ORDERS":false,"COLLECT_ONLY_FOR_AR":false,"TRIAL":true,"AUTO_CREATE_LICENSES":false,"ACH_DELIVERY":false},"SELLER_SETTINGS":{"Geolocation":true,"CollectPayDataForZeroOrders":false,"RecurringOpting":"opt_in"},"ACCOUNT_PURPOSE":"PRODUCTION","ONESTEPCART":true,"VISITOR_COUNTRY":"Brazil","VISITOR_COUNTRY_CODE":"br","BILLING_CURRENCY":"BRL","DISPLAY_CURRENCY":"BRL","BILLING_CURRENCY_SYMBOL":"R$","BILLING_CURRENCY_SYMBOL_POSITION":"left","DISPLAY_CURRENCY_SYMBOL":"R$","DISPLAY_CURRENCY_SYMBOL_POSITION":"left","BILLING_CURRENCY_DECIMAL_SEPARATOR":",","BILLING_CURRENCY_THOUSAND_SEPARATOR":".","DISPLAY_CURRENCY_DECIMAL_SEPARATOR":",","DISPLAY_CURRENCY_THOUSAND_SEPARATOR":".","CARD_DISPLAYED":0,"REF":"3397687","PAGE_NAME":"checkcart","CART_ID":"448f9aa180c57616de7927eb0715cf2c","VENDOR_CODE":"DELUXMEN","LANGUAGE":"en","CURRENCY":"BRL","CURRENCY_SYMBOL":"R$","CURRENCY_SYMBOL_POSITION":"left","INITIAL_FLOW":"Express Payments Checkout","INITIAL_SKIN":"Three-column checkout (Most popular)","CUSTOM_REQUEST":null,"CUSTOMIZATION_DEGREE":null,"OWNER":"Internal Team","TEMPLATE_TYPE":"NEW_STYLE","DEFAULT_TEMPLATE":false,"MERCHANT_DEFAULT_TEMPLATE":false,"TEMPLATE_ID":37440,"ASSISTED_SALE":false,"ORDER_VAT_PERCENTAGE":0,"PURCHASE_TYPE":"REGULAR","ORDER_AFFILIATE":null,"ORDER_AFFILIATE_COOKIE":0,"COMPANY_NAME":"Anton Pletnev","VENDOR_LOGO":"\/images\/merchant\/77369e37b2aa1404f416275183ab055f\/logo.jpg","VENDOR_URL":"https:\/\/mobirise.com","PRODUCT_ADDED_DETAILS":[],"PRODUCT_REMOVED_DETAILS":[],"CART_PRODUCTS":[{"DetailID":0,"ProductName":"Mobirise Site (Yearly)","ProductCode":"1EDF0E6731","ProductNameTranslated":"Mobirise Site (Yearly)","ProductGroup":"Mobirise","ProductShortDescription":"<p>Mobirise Site (Yearly)<\/p>","ProductID":"4551005","CrossParentProductID":null,"CrossSellAdded":false,"ProductPrice":268.99000000000001,"ProductPriceFull":268.99000000000001,"ProductTax":0,"ProductTotalPriceWithTax":268.99000000000001,"ProductTotalPriceWithTaxAndDiscount":268.99000000000001,"ProductTotalPriceWithTaxAndDiscountInDisplayedCurrency":268.99000000000001,"ProductTotalPriceWithoutTax":268.99000000000001,"ProductTotalPriceWithoutTaxAndDiscount":268.99000000000001,"ProductTotalPriceWithoutTaxAndDiscountInDisplayedCurrency":268.99000000000001,"ProductTotalPriceWithoutTaxInDisplayedCurrency":268.99000000000001,"ProductPriceDiscountPercent":0,"UpSellAdded":false,"ProductPriceGross":268.99000000000001,"ProductPriceGrossInDisplayCurrency":268.99000000000001,"ProductPriceFullInDisplayedCurrency":268.99000000000001,"ProductPriceDiscount":0,"ProductTaxInDisplayedCurrency":0,"ProductTotalPriceWithTaxInDisplayedCurrency":268.99000000000001,"ProductHasPhisicalDelivery":false,"ProductPriceInDisplayedCurrency":268.99000000000001,"ProductPriceDiscountInDisplayedCurrency":0,"OnlyOneQtyPurchase":"DISABLED","ProductCategory":"Site Management","ProductType":"REGULAR","ProductQuantity":1,"PurchaseType":"REGULAR","RenewalSettings":[{"RenewalInterval":12,"RenewalIntervalUnit":"MONTHS","ContractBillingCycles":0}],"ProductImages":{"60":"\/images\/merchant\/77369e37b2aa1404f416275183ab055f\/products\/60px_png256.png","80":"\/images\/merchant\/77369e37b2aa1404f416275183ab055f\/products\/80px_png256.png","100":"\/images\/merchant\/77369e37b2aa1404f416275183ab055f\/products\/100px_png256.png","150":"\/images\/merchant\/77369e37b2aa1404f416275183ab055f\/products\/150px_png256.png"},"ProductTaxPercentage":0,"ProductSKU":false}],"SESSION_ID":"e2647660a6a5af28eadda20bd5bdb98b","TERMS_AND_CONDITIONS_AGREEMENT_LINK":"'https:\/\/www.2co.com\/terms.html?MOR=active' target='_blank'","PRIVACY_POLICY_AGREEMENT_LINK":"'https:\/\/www.2co.com\/privacy.html?MOR=active' target='_blank'","TERMS_AND_CONDITIONS_AND_RENEWAL_AGREEMENT":"By placing this order you agree to the <a href='https:\/\/www.2co.com\/terms.html?MOR=active' target='_blank'>Terms and Conditions<\/a> and auto-renewal.","TERMS_AND_CONDITIONS_AGREEMENT":"By placing this order you agree to the <a href='https:\/\/www.2co.com\/terms.html?MOR=active' target='_blank'>Terms and Conditions<\/a>.","TERMS_AND_CONDITIONS_AGREEMENT_GDPR":"By completing my purchase I confirm that I am over 16 years of age and I agree to the <a href='https:\/\/www.2co.com\/terms.html?MOR=active' target='_blank'>Terms and Conditions<\/a>.","TERMS_AND_CONDITIONS_AGREEMENT_AUTORENEWAL_TOOLTIP_TEXT":"<p>By enabling automatic billing, your subscription will be automatically renewed before it expires, avoiding usage interruptions in a highly secure environment.<\/p><p>You can disable the auto-renewal option at any time.<\/p>","HIDE_AUTO_RENEWAL_CHECKBOX":0,"REQUEST_TIME":531.97216987609863};
            var cross_sell_products = [];
    
            window.US_TAX_COUNTRIES = [39,222,171,132];
    
    var _t_settings = {"hasPaypalLightbox":true,"paypalMerchantID":"H3T328DYJF9ZL","CHECKOUTLOGIN":0,"last_scenario_detected":"old","sso_with_express_checkout_feature_active":true,"p_delivery":[],"b_state":"S\u00e3o Paulo","PAYID":1,"BILLINGCOUNTRY":"29","payoptions":{"1":"Visa\/MasterCard","4":"American Express","14":"Discover","56":"UnionPay","2":"Bank transfer","8":"PayPal","11":"Purchase order"},"payoptions_address_assignments":{"1":{"0":"2","29":"2","222":"4"},"2":{"0":"2","81":"2","220":"2","222":"4"},"4":{"0":"2","29":"2","222":"4"},"6":["2"],"8":["2"],"11":{"0":"2","220":"2","222":"4"},"14":["4"],"17":["2"],"20":["2"],"21":{"0":"2","13":"2","81":"2","150":"2"},"23":["2"],"27":["2"],"37":["2"],"49":["4"],"56":["2"],"57":["2"],"58":["2"],"59":["2"],"60":["2"],"61":["2"],"62":["2"],"64":["2"],"69":["2"],"72":["2"],"74":["2"],"79":["2"]},"payoptions_default_address":2,"payoptions_addresses":{"2":"Verifone Payments BV dba 2Checkout | [Mail address: P.O. Box 11334, 1001 GH Amsterdam] Singel 250, 4th floor, 1016AB, Amsterdam, Netherlands","4":"Avangate Inc dba 2Checkout | 11700 Great Oaks Way no. 210, Alpharetta, 30022, USA"},"payoptions_countries":{"73":{"17":"Carte Bleue","21":"Direct Debit"},"45":{"20":"\u652f\u4ed8\u5b9d (Alipay)","6":"JCB","64":"WeChat Pay"},"81":{"21":"Direct Debit","6":"JCB","62":"Instant bank payment"},"150":{"23":"iDEAL","21":"Direct Debit","62":"Instant bank payment"},"29":{"27":"Boleto \/ Pix","57":"Elo Card","58":"Hipercard"},"57":{"37":"Dankort","62":"Instant bank payment","79":"MobilePay"},"13":{"21":"Direct Debit","6":"JCB","62":"Instant bank payment"},"96":{"20":"\u652f\u4ed8\u5b9d (Alipay)","6":"JCB","64":"WeChat Pay"},"204":{"20":"\u652f\u4ed8\u5b9d (Alipay)","6":"JCB"},"222":{"49":"eCheck\/ACH","6":"JCB"},"191":{"21":"Direct Debit","62":"Instant bank payment","6":"JCB"},"20":{"21":"Direct Debit","69":"Bancontact"},"72":{"59":"OP-Pohjola","61":"Danske","60":"Nordea","62":"Instant bank payment"},"201":{"62":"Instant bank payment"},"67":{"62":"Instant bank payment"},"16":{"6":"JCB"},"17":{"6":"JCB"},"33":{"6":"JCB"},"100":{"6":"JCB"},"107":{"6":"JCB"},"118":{"6":"JCB"},"141":{"6":"JCB"},"161":{"6":"JCB"},"167":{"6":"JCB"},"174":{"6":"JCB"},"184":{"6":"JCB"},"207":{"6":"JCB"},"229":{"6":"JCB"},"116":{"6":"JCB"},"113":{"6":"JCB"},"56":{"65":"Trustpay","62":"Instant bank payment"},"185":{"65":"Trustpay"},"220":{"62":"Instant bank payment"},"123":{"62":"Instant bank payment"},"117":{"62":"Instant bank payment"},"99":{"72":"NetBanking"},"159":{"74":"Vipps"},"75":{"17":"Carte Bleue"},"76":{"17":"Carte Bleue"},"77":{"17":"Carte Bleue"}},"payoptions_order":{"0":{"a":"1","b":"8","c":"4","d":"2"},"9":{"a":"1","b":"4","c":"43","d":"2"},"45":{"a":"1","b":"20","c":"56","d":"64","e":"8"},"174":{"a":"1","b":"48","c":"8","d":"24"},"222":{"a":"1","b":"8","c":"4","d":"14","e":"25","f":"49"},"107":{"a":"1","b":"6","c":"8","d":"4","e":"42","f":"5","g":"33"},"73":{"a":"1","b":"8","c":"4","d":"17","e":"2"},"29":{"a":"1","b":"8","c":"27","d":"4"},"189":{"a":"1","b":"8","c":"4","d":"2","e":"24"},"213":{"a":"1","b":"8","c":"4","d":"32","e":"2"},"159":{"a":"1","b":"8","c":"4","d":"5","e":"2"},"57":{"a":"1","b":"8","c":"37","d":"5","e":"4"},"201":{"a":"1","b":"8","c":"4","d":"2","e":"5"},"152":{"a":"1","b":"8","c":"63"},"12":{"a":"1","b":"8","c":"63","d":"4","e":"5"},"13":{"a":"1","b":"4","c":"8","d":"2","e":"16","f":"21","g":"62"},"20":{"a":"1","b":"4","c":"8","d":"69","e":"21","f":"2","g":"62"},"56":{"a":"1","b":"4","c":"8","d":"2","e":"62"},"81":{"a":"1","b":"4","c":"8","d":"16","e":"2","f":"21","g":"22","h":"62"},"220":{"a":"1","b":"4","c":"8","d":"2","e":"19","f":"55","g":"62"},"53":{"a":"1","b":"4","c":"8","d":"2","e":"62"},"123":{"a":"1","b":"4","c":"8","d":"2","e":"62"},"117":{"a":"1","b":"4","c":"8","d":"2","e":"62"},"185":{"a":"1","b":"4","c":"8","d":"2","e":"62"},"150":{"a":"1","b":"23","c":"4","d":"8","e":"62","f":"2"},"99":{"a":"1","b":"71","c":"72","d":"4","e":"2"},"113":{"a":"1","b":"8","c":"77","d":"2"}},"payoptions_icons":{"1":"creditcard.svg","2":"wiretransfer.gif","4":"creditcard-amex.gif","6":"creditcard-jcb.gif","8":"paypal.gif","11":"po.gif","14":"discover.gif","17":"carte-bleue.gif","20":"alipay.gif","21":"direct_debit.gif","23":"ideal.gif","27":"boleto.gif","37":"dankort.gif","49":"ach.gif","56":"unionpay.gif","57":"elo.gif","58":"hipercard.gif","59":"op-pohjola.gif","60":"nordea.gif","61":"danske-bank.gif","62":"trustly.gif","64":"wechat-pay.png","65":"trustpay.png","69":"mrcash.gif","72":"netbanking.png","74":"vipps-logo.png","79":"mobilepay-logo.png"},"payoptions_online":[1,1,1,4,4,4,6,14,17,37,56,57,58,50],"payoptions_recurring":{"1":"Visa\/MasterCard","4":"American Express","6":"JCB","8":"PayPal","14":"Discover","17":"Carte Bleue","20":"\u652f\u4ed8\u5b9d (Alipay)","21":"Direct Debit","23":"iDEAL","37":"Dankort","49":"eCheck\/ACH","56":"UnionPay","57":"Elo Card","58":"Hipercard"},"payoptions_terminals":{"8":"PAYPAL_EXPRESS","27":"PAGBRASIL","57":"PAGBRASIL","58":"PAGBRASIL","50":"PAGBRASIL"},"payoptions_terminal_settings":{"21":{"SEPA":1,"PROCESS_TYPE_EXTERNAL":false}},"payoptions_terminals_smart":{"1":{"29":"PAGBRASIL"},"2":[],"4":{"29":"PAGBRASIL"},"6":[],"8":["PAYPAL_EXPRESS"],"11":[],"14":[],"17":[],"20":[],"21":[],"23":[],"27":["PAGBRASIL"],"37":[],"49":[],"56":[],"57":["PAGBRASIL"],"58":["PAGBRASIL"],"59":[],"60":[],"61":[],"62":[],"64":[],"65":[],"69":[],"72":[],"74":[],"79":[]},"payoptions_terminals_installments":{"50":["PAGBRASIL"]},"accepted_cards":{"1":{"visa":"Visa","mastercard":"MasterCard","visaelectron":"Visa Electron","maestro":"Maestro","0":{"visa":"Visa","mastercard":"MasterCard","visaelectron":"Visa Electron","maestro":"Maestro"},"29":{"visa":"Visa","mastercard":"MasterCard"},"222":{"visa":"Visa","mastercard":"MasterCard","visaelectron":"Visa Electron","maestro":"Maestro"}},"4":{"amex":"American Express","0":{"amex":"American Express"},"29":{"amex":"American Express"},"222":{"amex":"American Express"}},"6":{"jcb":"JCB","0":{"jcb":"JCB"}},"14":{"discover":"Discover","0":{"discover":"Discover"}},"17":{"carte_bleue":"Carte Bleue","0":{"carte_bleue":"Carte Bleue"}},"37":{"dankort":"Dankort","0":{"dankort":"Dankort"}},"50":{"visa":"Visa","mastercard":"MasterCard","amex":"American Express","hipercard":"Hipercard","elo":"Elo"},"51":{"visa":"Visa","mastercard":"MasterCard","visaelectron":"Visa Electron","maestro":"Maestro"},"52":{"amex":"American Express"},"53":{"discover":"Discover"},"57":{"elo":"Elo","0":{"elo":"Elo"}},"58":{"hipercard":"Hipercard","0":{"hipercard":"Hipercard"}},"5":{"diners":"Diners Club"},"68":{"visa":"Visa","mastercard":"MasterCard","amex":"American Express","discover":"Discover","jcb":"Jcb"},"70":{"mir":"Mir"},"71":{"rupay":"RuPay"},"56":{"unionpay":"UnionPay","0":{"unionpay":"UnionPay"}}},"payoptions_currencies":{"1":{"0":{"AED":"AED - United Arab Emirates Dirham","AUD":"AUD - Australian Dollar","BGN":"BGN - Bulgarian Lev","BOB":"BOB - Bolivian peso","BRL":"BRL - Brazilian Real","BYN":"BYN - Belarusian Ruble","CAD":"CAD - Canadian Dollar","CHF":"CHF - Swiss Franc","CLP":"CLP - Chilean Peso","CNY":"CNY - China Yuan Renminbi","COP":"COP - Colombian Peso","CZK":"CZK - Czech Koruna","DKK":"DKK - Danish Krone","DZD":"DZD - Algerian Dinar","EGP":"EGP - Egyptian Pound","EUR":"EUR - Euro","GBP":"GBP - Great British Pound","HKD":"HKD - Hong Kong Dollar","HUF":"HUF - Hungarian Forint","ILS":"ILS - Israeli New Sheqel","INR":"INR - Indian Rupee","JPY":"JPY - Japanese Yen","KES":"KES - Kenyan Shilling","KRW":"KRW - South Korean Won","MDL":"MDL - Moldavian Lei","MXN":"MXN - Mexican Peso","NAD":"NAD - Namibian dollar","NGN":"NGN - Nigerian naira","NOK":"NOK - Norwegian Krone","NZD":"NZD - New Zealand Dollars","OMR":"OMR - Omani Rial","PEN":"PEN - Peruvian nuevo sol","PLN":"PLN - Polish Zloty","PYG":"PYG - Paraguayan Guaran\u00ed","QAR":"QAR - Qatar Riyal","RON":"RON - Romanian Leu","RSD":"RSD - Serbian Dinar","RUB":"RUB - Russian Rubles","SAR":"SAR - Saudi Riyal","SEK":"SEK - Swedish Krona","SGD":"SGD - Singapore Dollar","TND":"TND - Tunisian Dinar","TRY":"TRY - Turkish Lira","TWD":"TWD - New Taiwan Dollar","UAH":"UAH - Ukrainian Grivna","USD":"USD - United States Dollar","UYU":"UYU - Uruguayan Peso","VND":"VND - Vietnamese Dong","ZAR":"ZAR - South African Rand"},"29":{"BRL":"BRL - Brazilian Real"},"222":{"USD":"USD - United States Dollar"}},"2":{"0":{"EUR":"EUR - Euro","USD":"USD - United States Dollar"},"81":{"EUR":"EUR - Euro"},"220":{"EUR":"EUR - Euro","GBP":"GBP - Great British Pound","USD":"USD - United States Dollar"},"222":{"USD":"USD - United States Dollar"}},"4":{"0":{"AUD":"AUD - Australian Dollar","CAD":"CAD - Canadian Dollar","EUR":"EUR - Euro","GBP":"GBP - Great British Pound","JPY":"JPY - Japanese Yen","MXN":"MXN - Mexican Peso","USD":"USD - United States Dollar"},"29":{"BRL":"BRL - Brazilian Real"},"222":{"USD":"USD - United States Dollar"}},"6":[{"EUR":"EUR - Euro","JPY":"JPY - Japanese Yen","USD":"USD - United States Dollar"}],"8":[{"AUD":"AUD - Australian Dollar","CAD":"CAD - Canadian Dollar","CHF":"CHF - Swiss Franc","CZK":"CZK - Czech Koruna","DKK":"DKK - Danish Krone","EUR":"EUR - Euro","GBP":"GBP - Great British Pound","HKD":"HKD - Hong Kong Dollar","HUF":"HUF - Hungarian Forint","ILS":"ILS - Israeli New Sheqel","JPY":"JPY - Japanese Yen","MXN":"MXN - Mexican Peso","NOK":"NOK - Norwegian Krone","NZD":"NZD - New Zealand Dollars","PLN":"PLN - Polish Zloty","RUB":"RUB - Russian Rubles","SEK":"SEK - Swedish Krona","SGD":"SGD - Singapore Dollar","TWD":"TWD - New Taiwan Dollar","USD":"USD - United States Dollar"}],"11":{"0":{"EUR":"EUR - Euro","USD":"USD - United States Dollar"},"220":{"EUR":"EUR - Euro","GBP":"GBP - Great British Pound","USD":"USD - United States Dollar"},"222":{"USD":"USD - United States Dollar"}},"14":[{"USD":"USD - United States Dollar"}],"17":[{"EUR":"EUR - Euro"}],"20":[{"CNY":"CNY - China Yuan Renminbi","USD":"USD - United States Dollar"}],"21":{"0":{"EUR":"EUR - Euro"},"13":{"EUR":"EUR - Euro"},"81":{"EUR":"EUR - Euro"},"150":{"EUR":"EUR - Euro"}},"23":[{"EUR":"EUR - Euro"}],"27":[{"BRL":"BRL - Brazilian Real"}],"37":[{"DKK":"DKK - Danish Krone","EUR":"EUR - Euro"}],"49":[{"USD":"USD - United States Dollar"}],"56":[{"AUD":"AUD - Australian Dollar","BRL":"BRL - Brazilian Real","CAD":"CAD - Canadian Dollar","CHF":"CHF - Swiss Franc","CNY":"CNY - China Yuan Renminbi","EUR":"EUR - Euro","GBP":"GBP - Great British Pound","HKD":"HKD - Hong Kong Dollar","JPY":"JPY - Japanese Yen","PLN":"PLN - Polish Zloty","RUB":"RUB - Russian Rubles","SEK":"SEK - Swedish Krona","SGD":"SGD - Singapore Dollar","TWD":"TWD - New Taiwan Dollar","USD":"USD - United States Dollar","ZAR":"ZAR - South African Rand"}],"57":[{"BRL":"BRL - Brazilian Real"}],"58":[{"BRL":"BRL - Brazilian Real"}],"59":[{"EUR":"EUR - Euro"}],"60":[{"EUR":"EUR - Euro"}],"61":[{"EUR":"EUR - Euro"}],"62":[{"CZK":"CZK - Czech Koruna","DKK":"DKK - Danish Krone","EUR":"EUR - Euro","GBP":"GBP - Great British Pound","HUF":"HUF - Hungarian Forint","NOK":"NOK - Norwegian Krone","SEK":"SEK - Swedish Krona"}],"64":[{"CNY":"CNY - China Yuan Renminbi","HKD":"HKD - Hong Kong Dollar","SGD":"SGD - Singapore Dollar","USD":"USD - United States Dollar"}],"65":[{"USD":"USD","EUR":"EUR","GBP":"GBP","RON":"RON","AUD":"AUD","CAD":"CAD","CHF":"CHF","CZK":"CZK","DKK":"DKK","HUF":"HUF","JPY":"JPY","NOK":"NOK","PLN":"PLN","SEK":"SEK","TRY":"TRY","RUB":"RUB","CNY":"CNY","BGN":"BGN","BRL":"BRL","HKD":"HKD","KRW":"KRW","MXN":"MXN","NZD":"NZD","SGD":"SGD","ZAR":"ZAR","MDL":"MDL","AED":"AED","EGP":"EGP","INR":"INR","RSD":"RSD","UAH":"UAH","TWD":"TWD","ILS":"ILS","SYP":"SYP","JOD":"JOD","KWD":"KWD","OMR":"OMR","QAR":"QAR","SAR":"SAR","ARS":"ARS","CLP":"CLP","BOB":"BOB","COP":"COP","PYG":"PYG","PEN":"PEN","UYU":"UYU","NGN":"NGN","NAD":"NAD","TND":"TND","DZD":"DZD","KES":"KES","VND":"VND","BYN":"BYN"}],"69":[{"EUR":"EUR - Euro"}],"72":[{"INR":"INR - Indian Rupee"}],"74":[{"NOK":"NOK - Norwegian Krone"}],"79":[{"DKK":"DKK - Danish Krone"}]},"fallback_currencies":{"2":"USD","9":"USD","12":"USD","13":"EUR","17":"USD","19":"USD","20":"EUR","25":"USD","29":"USD","33":"EUR","39":"USD","44":"USD","45":"USD","48":"USD","52":"USD","53":"EUR","55":"EUR","56":"EUR","57":"EUR","60":"USD","63":"USD","64":"USD","67":"EUR","72":"EUR","73":"EUR","75":"EUR","81":"EUR","84":"EUR","87":"EUR","89":"USD","93":"USD","95":"USD","96":"USD","97":"EUR","98":"EUR","99":"USD","100":"USD","102":"EUR","104":"USD","105":"EUR","107":"USD","108":"USD","113":"USD","114":"USD","117":"EUR","118":"USD","123":"EUR","124":"EUR","128":"USD","131":"EUR","133":"EUR","137":"USD","139":"EUR","140":"EUR","150":"EUR","152":"USD","153":"USD","159":"EUR","160":"USD","163":"USD","165":"USD","166":"USD","167":"USD","169":"EUR","170":"EUR","172":"USD","173":"EUR","174":"USD","180":"USD","184":"USD","185":"EUR","186":"EUR","189":"USD","191":"EUR","192":"USD","201":"EUR","202":"EUR","204":"USD","212":"USD","213":"EUR","218":"UAH","219":"USD","220":"EUR","222":"USD","224":"USD","228":"USD","237":"EUR","241":"EUR","242":"USD","246":"GBP"},"countries_states":{"240":[],"1":[],"2":[],"3":[],"4":[],"5":[],"6":[],"7":[],"8":[],"9":[],"10":[],"11":[],"12":[],"13":[],"14":[],"15":[],"16":[],"17":[],"18":[],"19":[],"20":[],"21":[],"22":[],"23":[],"24":[],"25":[],"26":[],"27":[],"28":[],"29":["Acre","Alagoas","Amap\u00e1","Amazonas","Bahia","Cear\u00e1","Distrito Federal","Esp\u00edrito Santo","Goias","Maranh\u00e3o","Mato Grosso","Mato Grosso do Sul","Minas Gerais","Par\u00e1","Para\u00edba","Paran\u00e1","Pernambuco","Piau\u00ed","Rio de Janeiro","Rio Grande do Norte","Rio Grande do Sul","Rond\u00f4nia","Roraima","Santa Catarina","S\u00e3o Paulo","Sergipe","Tocantins"],"30":[],"32":[],"33":[],"34":[],"35":[],"37":[],"38":[],"39":["Alberta","British Columbia","Manitoba","New Brunswick","Newfoundland and Labrador","Northwest Territories","Nova Scotia","Nunavut","Ontario","Prince Edward Island","Quebec","Saskatchewan","Yukon Territory"],"241":[],"40":[],"41":[],"42":[],"43":[],"44":[],"45":[],"46":[],"47":[],"48":[],"49":[],"50":[],"51":[],"52":[],"53":[],"55":[],"56":[],"234":[],"57":[],"58":[],"59":[],"60":[],"61":[],"62":[],"63":[],"64":[],"65":[],"66":[],"67":[],"200":[],"68":[],"69":[],"70":[],"71":[],"72":[],"73":["Ain","Aisne","Allier","Alpes-de-Haute-Provence","Alpes-Maritimes","Ard\u00e8che","Ardennes","Ari\u00e8ge","Aube","Aude","Aveyron","Bas-Rhin","Bouches-du-Rh\u00f4ne","Calvados","Cantal","Charente","Charente-Maritime","Cher","Corr\u00e8ze","Corse-du-Sud","C\u00f4te-d'Or","C\u00f4tes-d'Armor","Creuse","Deux-S\u00e8vres","Dordogne","Doubs","Dr\u00f4me","Essonne","Eure","Eure-et-Loir","Finist\u00e8re","Gard","Gers","Gironde","Haut-Rhin","Haute-Corse","Haute-Garonne","Haute-Loire","Haute-Marne","Haute-Sa\u00f4ne","Haute-Savoie","Haute-Vienne","Hautes-Alpes","Hautes-Pyr\u00e9n\u00e9es","Hauts-de-Seine","H\u00e9rault","Ille-et-Vilaine","Indre","Indre-et-Loire","Is\u00e8re","Jura","Landes","Loir-et-Cher","Loire","Loire-Atlantique","Loiret","Lot","Lot-et-Garonne","Loz\u00e8re","Maine-et-Loire","Manche","Marne","Mayenne","Meurthe-et-Moselle","Meuse","Morbihan","Moselle","Ni\u00e8vre","Nord","Oise","Orne","Paris","Pas-de-Calais","Puy-de-D\u00f4me","Pyr\u00e9n\u00e9es-Atlantiques","Pyr\u00e9n\u00e9es-Orientales","Rh\u00f4ne","Sa\u00f4ne-et-Loire","Sarthe","Savoie","Seine-et-Marne","Seine-Maritime","Seine-Saint-Denis","Somme","Tarn","Tarn-et-Garonne","Territoire de Belfort","Val-d'Oise","Val-de-Marne","Var","Vaucluse","Vend\u00e9e","Vienne","Vosges","Yonne","Yvelines"],"75":[],"76":[],"77":[],"78":[],"79":[],"80":[],"81":[],"82":[],"83":[],"84":[],"85":[],"86":[],"87":[],"88":[],"89":[],"90":[],"91":[],"92":[],"93":[],"94":[],"95":[],"96":[],"97":[],"98":[],"99":["Andaman and Nicobar Islands","Andhra Pradesh","Andhra Pradesh (New)","Arunachal Pradesh","Assam","Bihar","Chandigarh","Chattisgarh","Dadra and Nagar Haveli","Daman and Diu","Delhi","Goa","Gujarat","Haryana","Himachal Pradesh","Jammu and Kashmir","Jharkhand","Karnataka","Kerala","Lakshadweep Islands","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Pondicherry","Punjab","Rajasthan","Sikkim","Tamil Nadu","Telangana","Tripura","Uttar Pradesh","Uttarakhand","West Bengal"],"100":[],"101":[],"102":[],"104":[],"105":[],"36":[],"106":[],"107":[],"245":[],"108":[],"109":[],"110":[],"111":[],"113":[],"114":[],"115":[],"116":[],"117":[],"118":[],"119":[],"120":[],"122":[],"123":[],"124":[],"125":[],"239":[],"126":[],"127":[],"128":[],"129":[],"130":[],"131":[],"238":[],"132":[],"133":[],"134":[],"135":[],"136":[],"137":[],"138":[],"139":[],"140":[],"141":[],"142":[],"143":[],"144":[],"145":[],"146":[],"147":[],"148":[],"150":[],"151":[],"152":[],"153":[],"154":[],"155":[],"156":[],"157":[],"158":[],"159":[],"160":[],"161":[],"162":[],"163":[],"164":[],"165":[],"166":[],"167":[],"168":[],"169":[],"170":[],"171":[],"172":[],"173":[],"237":["Alba","Arad","Arges","Bacau","Bihor","Bistrita-Nasaud","Botosani","Braila","Brasov","Bucuresti - Sector 1","Bucuresti - Sector 2","Bucuresti - Sector 3","Bucuresti - Sector 4","Bucuresti - Sector 5","Bucuresti - Sector 6","Buzau","Calarasi","Caras-Severin","Cluj","Constanta","Covasna","Dambovita","Dolj","Galati","Giurgiu","Gorj","Harghita","Hunedoara","Ialomita","Iasi","Ilfov","Maramures","Mehedinti","Mures","Neamt","Olt","Prahova","Salaj","Satu Mare","Sibiu","Suceava","Teleorman","Timis","Tulcea","Valcea","Vaslui","Vrancea"],"174":[],"175":[],"176":[],"177":[],"178":[],"179":[],"180":[],"181":[],"242":[],"182":[],"183":[],"184":[],"249":[],"185":[],"186":[],"187":[],"188":[],"189":[],"190":[],"191":[],"192":[],"193":[],"194":[],"195":[],"196":[],"198":[],"199":[],"201":[],"202":[],"204":[],"205":[],"206":[],"207":[],"208":[],"209":[],"210":[],"211":[],"212":[],"213":[],"214":[],"215":[],"216":[],"221":[],"217":[],"218":["Cherkasy","Chernihiv","Chernivtsi","Dnipropetrovsk","Ivano-Frankivsk","Kharkiv","Khmelnytskyi","Kirovohrad","Kyiv","Lviv","Mykolaiv","Odessa","Poltava","Rivne","Sumy","Ternopil","Vinnytsia","Volyn","Zakarpattia","Zhytomyr"],"219":[],"220":[],"222":["Alabama","Alaska","Arizona","Arkansas","Armed Forces - (USA\/Canada)","Armed Forces - Europe","Armed Forces - Pacific","California","Colorado","Connecticut","Delaware","District of Columbia","Florida","Georgia","Hawaii","Idaho","Illinois","Indiana","Iowa","Kansas","Kentucky","Louisiana","Maine","Maryland","Massachusetts","Michigan","Minnesota","Mississippi","Missouri","Montana","Nebraska","Nevada","New Hampshire","New Jersey","New Mexico","New York","North Carolina","North Dakota","Ohio","Oklahoma","Oregon","Pennsylvania","Rhode Island","South Carolina","South Dakota","Tennessee","Texas","Utah","Vermont","Virginia","Washington","West Virginia","Wisconsin","Wyoming"],"224":[],"225":[],"226":[],"227":[],"228":[],"229":[],"223":[],"31":[],"230":[],"231":[],"232":[],"235":[],"236":[]},"country_epg_groups":{"254":[],"240":[],"1":[],"2":[],"3":[],"4":[],"5":[],"6":[],"7":[],"8":[],"9":[],"10":[],"11":[],"12":[],"13":["EU","GDPR","SEPA"],"14":[],"15":[],"16":[],"17":[],"18":[],"19":[],"20":["EU","GDPR","SEPA"],"21":[],"22":[],"23":[],"24":[],"25":[],"250":[],"26":[],"27":[],"28":[],"29":[],"30":[],"31":[],"32":[],"33":["EU","GDPR","SEPA"],"34":[],"35":[],"37":[],"38":[],"39":[],"241":[],"40":[],"41":[],"42":[],"43":[],"44":[],"45":[],"46":[],"47":[],"48":[],"49":[],"50":[],"51":[],"52":[],"53":["EU","GDPR","SEPA"],"248":[],"55":["EU","GDPR","SEPA"],"56":["EU","GDPR","SEPA"],"234":[],"57":["EU","GDPR","SEPA"],"58":[],"59":[],"60":[],"61":[],"62":[],"63":[],"64":[],"65":[],"66":[],"67":["EU","GDPR","SEPA"],"68":[],"69":[],"70":[],"71":[],"72":["EU","GDPR","SEPA"],"73":["EU","GDPR","SEPA"],"75":[],"76":[],"77":[],"78":[],"79":[],"80":[],"81":["EU","GDPR","SEPA"],"82":[],"83":[],"84":["EU","GDPR","SEPA"],"85":[],"86":[],"87":[],"88":[],"89":[],"244":[],"90":[],"91":[],"92":[],"93":[],"94":[],"95":[],"96":[],"97":["EU","GDPR","SEPA"],"98":["GDPR","SEPA"],"99":[],"100":[],"101":[],"102":["EU","GDPR","SEPA"],"104":[],"105":["EU","GDPR","SEPA"],"36":[],"106":[],"107":[],"245":[],"108":[],"109":[],"110":[],"111":[],"113":[],"255":[],"114":[],"115":[],"116":[],"117":["EU","GDPR","SEPA"],"118":[],"119":[],"120":[],"122":["GDPR"],"123":["EU","GDPR","SEPA"],"124":["EU","GDPR","SEPA"],"125":[],"239":[],"126":[],"127":[],"128":[],"129":[],"130":[],"131":["EU","GDPR","SEPA"],"238":[],"132":[],"133":[],"134":[],"135":[],"136":[],"137":[],"138":[],"139":[],"140":[],"141":[],"243":[],"142":[],"143":[],"144":[],"145":[],"146":[],"147":[],"148":[],"150":["EU","GDPR","SEPA"],"151":[],"152":[],"153":[],"154":[],"155":[],"156":[],"157":[],"158":[],"159":["GDPR","SEPA"],"160":[],"161":[],"162":[],"247":[],"163":[],"164":[],"165":[],"166":[],"167":[],"168":[],"169":["EU","GDPR","SEPA"],"170":["EU","GDPR","SEPA"],"171":[],"172":[],"173":[],"237":["EU","GDPR","SEPA"],"174":[],"175":[],"176":[],"256":[],"177":[],"178":[],"179":[],"180":[],"181":[],"242":[],"182":[],"183":[],"184":[],"249":[],"185":["EU","GDPR","SEPA"],"186":["EU","GDPR","SEPA"],"187":[],"188":[],"189":[],"190":[],"251":[],"191":["EU","GDPR","SEPA"],"192":[],"193":[],"194":[],"195":[],"196":[],"198":[],"199":[],"200":[],"201":["EU","GDPR","SEPA"],"202":["GDPR","SEPA"],"204":[],"205":[],"206":[],"207":[],"208":[],"209":[],"210":[],"211":[],"212":[],"213":[],"214":[],"215":[],"216":[],"221":[],"217":[],"218":[],"219":[],"220":["EU","GDPR","SEPA"],"222":[],"224":[],"225":[],"226":[],"227":[],"228":[],"229":[],"223":[],"230":[],"231":[],"232":[],"235":[],"236":[]},"seller_id_country":"60","is_trial_order":false,"has_trial_products":false,"allow_free_order":true,"has_physical_delivery":false,"us_tax_countries":[39,222,171,132],"us_shipping_type_countries":[222,171,88,221,223,3,158,162,138],"eu_countries":["-237","12","13","16","19","20","33","39","44","48","53","55","56","57","63","67","72","73","74","81","84","97","98","99","102","105","110","113","117","123","124","128","131","139","150","152","159","169","170","180","184","185","186","191","201","202","204","207","213","217","218","219","220","235","237","242"],"cart_options":{"PRE_FILLED_ORDER":null,"DISABLE_IN_CONTEXT":0,"CARD":2,"DESIGN_TYPE":2,"AUTO_PREFILL":0,"SHORT_FORM":true,"CART":1,"DOTEST":false},"r_account":true,"total_cost":268.99000000000001,"payoptions_installments":{"1":{"installments":{"BRL":{"50:BRL:1:268.99:268.99":"1 x R$ 268,99","50:BRL:2:134.50:268.99":"2 x R$ 134,50","50:BRL:3:89.66:268.99":"3 x R$ 89,66","50:BRL:4:67.25:268.99":"4 x R$ 67,25","50:BRL:5:53.80:268.99":"5 x R$ 53,80","50:BRL:6:44.83:268.99":"6 x R$ 44,83"}},"countries":[29]},"4":{"installments":{"BRL":{"50:BRL:1:268.99:268.99":"1 x R$ 268,99","50:BRL:2:134.50:268.99":"2 x R$ 134,50","50:BRL:3:89.66:268.99":"3 x R$ 89,66","50:BRL:4:67.25:268.99":"4 x R$ 67,25","50:BRL:5:53.80:268.99":"5 x R$ 53,80","50:BRL:6:44.83:268.99":"6 x R$ 44,83"}},"countries":[29]},"8":{"installments":{"BRL":{"50:BRL:1:268.99:268.99":"1 x R$ 268,99"}},"countries":[29]},"11":{"installments":{"BRL":{"50:BRL:1:268.99:268.99":"1 x R$ 268,99"}},"countries":[29]},"14":{"installments":{"BRL":{"50:BRL:1:268.99:268.99":"1 x R$ 268,99"}},"countries":[29]},"56":{"installments":{"BRL":{"50:BRL:1:268.99:268.99":"1 x R$ 268,99"}},"countries":[29]},"27":{"installments":{"BRL":{"50:BRL:1:268.99:268.99":"1 x R$ 268,99"}},"countries":[29]},"57":{"installments":{"BRL":{"50:BRL:1:268.99:268.99":"1 x R$ 268,99","50:BRL:2:134.50:268.99":"2 x R$ 134,50","50:BRL:3:89.66:268.99":"3 x R$ 89,66","50:BRL:4:67.25:268.99":"4 x R$ 67,25","50:BRL:5:53.80:268.99":"5 x R$ 53,80","50:BRL:6:44.83:268.99":"6 x R$ 44,83"}},"countries":[29]},"58":{"installments":{"BRL":{"50:BRL:1:268.99:268.99":"1 x R$ 268,99","50:BRL:2:134.50:268.99":"2 x R$ 134,50","50:BRL:3:89.66:268.99":"3 x R$ 89,66","50:BRL:4:67.25:268.99":"4 x R$ 67,25","50:BRL:5:53.80:268.99":"5 x R$ 53,80","50:BRL:6:44.83:268.99":"6 x R$ 44,83"}},"countries":[29]}},"payoptions_translated_currencies":{"AED":"AED - United Arab Emirates Dirham","AFN":"AFN - Afghan Afghani","ALL":"ALL - Albanian Lek","ARS":"ARS - Argentine Peso","AUD":"AUD - Australian Dollar","AZN":"AZN - Azerbaijan Manat","BBD":"BBD - Barbadian dollar","BDT":"BDT - Bangladeshi Taka","BGN":"BGN - Bulgarian Lev","BHD":"BHD - Bahrain Dinar","BMD":"BMD - Bermudian Dollar","BND":"BND - Bruneian Dollar","BOB":"BOB - Bolivian peso","BRL":"BRL - Brazilian Real","BSD":"BSD - Bahamian Dollar","BWP":"BWP - Botswana Pula","BYN":"BYN - Belarusian Ruble","BYR":"BYR - Belarusian Ruble","BZD":"BZD - Belizean Dollar","CAD":"CAD - Canadian Dollar","CHF":"CHF - Swiss Franc","CLP":"CLP - Chilean Peso","CNY":"CNY - China Yuan Renminbi","COP":"COP - Colombian Peso","CRC":"CRC - Costa Rican Colon","CZK":"CZK - Czech Koruna","DKK":"DKK - Danish Krone","DOP":"DOP - Dominican Peso","DZD":"DZD - Algerian Dinar","EGP":"EGP - Egyptian Pound","EUR":"EUR - Euro","FJD":"FJD - Fijian Dollar","GBP":"GBP - Great British Pound","GEL":"GEL - Georgian Lari","GTQ":"GTQ - Guatemalan Quetzal","HKD":"HKD - Hong Kong Dollar","HNL":"HNL - Honduran Lempira","HRK":"HRK - Croatian Kuna","HTG":"HTG - Haitian Gourde","HUF":"HUF - Hungarian Forint","IDR":"IDR - Indonesian Rupiah","ILS":"ILS - Israeli New Sheqel","INR":"INR - Indian Rupee","JMD":"JMD - Jamaican Dollar","JOD":"JOD - Jordanian Dinar","JPY":"JPY - Japanese Yen","KES":"KES - Kenyan Shilling","KRW":"KRW - South Korean Won","KWD":"KWD - Kuwaiti Dinar","KZT":"KZT - Kazakhstani Tenge","LAK":"LAK - Laotian Kip","LBP":"LBP - Lebanese Pound","LKR":"LKR - Sri Lankan Rupee","LRD":"LRD - Liberian Dollar","MAD":"MAD - Moroccan Dirham","MDL":"MDL - Moldavian Lei","MMK":"MMK - Myanmar Kyat","MOP":"MOP - Macanese Pataca","MRO":"MRO - Mauritanian Ouguiya","MUR":"MUR - Mauritian Rupee","MVR":"MVR - Maldivian Rufiyaa","MXN":"MXN - Mexican Peso","MYR":"MYR - Malaysian Ringgit","NAD":"NAD - Namibian dollar","NGN":"NGN - Nigerian naira","NIO":"NIO - Nicaraguan C\u00f3rdoba","NOK":"NOK - Norwegian Krone","NPR":"NPR - Nepalese Rupee","NZD":"NZD - New Zealand Dollars","OMR":"OMR - Omani Rial","PAB":"PAB - Panamanian Balboa","PEN":"PEN - Peruvian nuevo sol","PGK":"PGK - Papua New Guinean Kina","PHP":"PHP - Philippino Peso","PKR":"PKR - Pakistani Rupee","PLN":"PLN - Polish Zloty","PYG":"PYG - Paraguayan Guaran\u00ed","QAR":"QAR - Qatar Riyal","RON":"RON - Romanian Leu","RSD":"RSD - Serbian Dinar","RUB":"RUB - Russian Rubles","SAR":"SAR - Saudi Riyal","SBD":"SBD - Solomon Islands Dollar","SCR":"SCR - Seychellois Rupee","SEK":"SEK - Swedish Krona","SGD":"SGD - Singapore Dollar","SVC":"SVC - Salvadoran Col\u00f3n","SYP":"SYP - Syrian Pound","THB":"THB - Thailand Baht","TND":"TND - Tunisian Dinar","TOP":"TOP - Tongan Pa\u02bbanga","TRY":"TRY - Turkish Lira","TTD":"TTD - Trinidad & Tobago Dollar","TWD":"TWD - New Taiwan Dollar","UAH":"UAH - Ukrainian Grivna","USD":"USD - United States Dollar","UYU":"UYU - Uruguayan Peso","VEF":"VEF - Venezuelan Bol\u00edvar","VND":"VND - Vietnamese Dong","VUV":"VUV - Vanuatu Vatu","WST":"WST - Samoan t\u0101l\u0101","XCD":"XCD - East Caribbean Dollar","XOF":"XOF - West African CFA Franc","YER":"YER - Yemeni Rial","ZAR":"ZAR - South African Rand"},"SELECTED_INSTALLMENTS_KEY":null,"AUTO_RENEWAL_TOOLTIP":"<p>By enabling automatic billing, your subscription will be automatically renewed before it expires, avoiding usage interruptions in a highly secure environment.<\/p><p>You can disable the auto-renewal option at any time.<\/p>","AUTO_RENEWAL_DETAILS":"Details","AUTO_RENEWAL_PRODUCTS":"Enable auto-renewal for this order","COUNTRY_STATE_MANDATORY":[222,213,99,39,29,73],"COUNTRY_ZIP_MANDATORY":[222,29,99],"COUNTRY_NATIONALID_MANDATORY":[213],"COUNTRY_VATID_MANDATORY":[213,242],"COUNTRY_COMPANY_MANDATORY":[213],"BILLING_CURRENCY":"BRL","PE_TOKEN":false,"payoptions_unfiltered":{"1":"Visa\/MasterCard","2":"Bank transfer","4":"American Express","6":"JCB","8":"PayPal","11":"Purchase order","14":"Discover","17":"Carte Bleue","20":"\u652f\u4ed8\u5b9d (Alipay)","21":"Direct Debit","23":"iDEAL","27":"Boleto \/ Pix","37":"Dankort","49":"eCheck\/ACH","56":"UnionPay","57":"Elo Card","58":"Hipercard","59":"OP-Pohjola","60":"Nordea","61":"Danske","62":"Instant bank payment","64":"WeChat Pay","65":"Trustpay","69":"Bancontact","72":"NetBanking","74":"Vipps","79":"MobilePay"}};
    _t_settings.trans = {};
    _t_settings.trans.popup_msg = "The online ordering system was not been able to open the pop-up payment window.\n In order to finalize the payment, you need to allow pop-ups from our website.\n Please check the settings for your pop-up blocker.";
    _t_settings.trans.state = "State or province";
    _t_settings.trans.city = "City";
    _t_settings.trans.country = "Country";
    _t_settings.trans.address = "Address";
    _t_settings.trans.delivery_js1 = "You have already submitted the following delivery information";
    _t_settings.trans.delivery_js2 = "The delivery will be made at the coordinates above only,\r\nsince the shipping price was estimated in accordance with\r\nthe data you have provided.";
    _t_settings.trans.ck_error1 = "Fields marked in red must be filled in correctly.\r\nTo continue, please review the entered data.";
    _t_settings.trans.ck_error_threshold = "Promotion criteria not met";
    _t_settings.trans.nodelivery2 = "The selected products cannot be delivered at the specified address. No physical delivery available for this area.";
    _t_settings.trans.please_select = "Please select";
    _t_settings.trans.hashBackupMedia = false;
    _t_settings.trans.ord_interface = "AVANGATE";

    var subscriptionMethods = [1,4,6,8,14,17,20,21,23,37,49,56,57,58,68];
    var subscriptionProducts = {"4551005":"Mobirise Site (Yearly)"};

            var available_payopt = document.getElementById('payment');
    
    var product_options = [];
    </script>




                    </div>
                

    

    
        
    

    
    <script type="text/javascript" language="javascript" src="https://secure.avangate.com/static/js-order-44e25db7df77ff43139a87e8c6d0d22e-V110/20250630164206.js"></script>


<script type="text/javascript" language="javascript">
	        (function($) {
            if (!$.curCSS) {
                $.curCSS = $.css;
            }
        })(jQuery);
    ;


    var isCursorOnList = false;
    var currentPlaceholder = '';

    $(".avangate-custom-select>ul").mouseenter(function(){isCursorOnList=true;});
    $(".avangate-custom-select>ul").mouseleave(function(){isCursorOnList=false;});

    var oldInput = $('.avangate-custom-select input#search-input').data('old');

    if (oldInput != '') {
        $('.avangate-custom-select ul li').each(function( index ) {
            if ($(this).data('id') == oldInput) {
                $('.avangate-custom-select input#search-input').attr('placeholder', $(this).data('name'));

                return false;
            }
        });
    }

    $(".avangate-custom-select input#search-input").live("keyup", function() {
        var value = $(this).val().toLowerCase();

        $(".avangate-custom-select>ul li").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });

    $('.avangate-custom-select input#search-input').live('blur', function(){
        if (!isCursorOnList) {
            hideList();
        }
    });

    $('.avangate-custom-select input#search-input').live('change', function(){
        var selectedValueInput = $('.avangate-custom-select input#select-value');
        var selectLabel = $('.custom-select-cell');

        if (selectedValueInput.val() != '') {
            $(this).removeClass('order__select__field__error');
            selectLabel.removeClass('order__checkout__form__label__error');
            selectLabel.find('span.order__text__label').removeClass('order__text__label__error');
        } else {
            $(this).addClass('order__select__field__error');
            selectLabel.addClass('order__checkout__form__label__error');
            selectLabel.find('span.order__text__label').addClass('order__text__label__error');
        }
    });

    $('.avangate-custom-select input#search-input').live("focus", function() {
        showList()
    });

    $('.avangate-custom-select>ul>li').live("click", function() {
        var name = $(this).data("name");
        var id = $(this).data("id");

        $('.avangate-custom-select>ul li').removeClass('selected');
        $(this).addClass('selected');
        currentPlaceholder = name;

        $('.avangate-custom-select input#select-value').val(id).change();
    });

    $('.avangate-custom-select input#select-value').live('change', function() {
        hideList();
    });

    function showList() {
        var searchInput = $('.avangate-custom-select input#search-input');

        $('.avangate-custom-select>ul').css({
            'margin-left': searchInput.position().left-11,
            'width': searchInput.width()+10
        });

        $('.avangate-custom-select>ul').show();
        currentPlaceholder = $('.avangate-custom-select input#search-input').attr('placeholder');

        searchInput.removeAttr('readonly');
        searchInput.attr('placeholder', 'Search....')
    }

    function hideList() {
        $('.avangate-custom-select>ul').hide();

        var searchInput = $('.avangate-custom-select input#search-input');
        var selectedValueInput = $('.avangate-custom-select input#select-value');
        var selectLabel = $('.custom-select-cell');

        searchInput.val('');
        searchInput.keyup();
        searchInput.attr('readonly');
        searchInput.attr('placeholder', currentPlaceholder)

        if (selectedValueInput.val() != '') {
            searchInput.removeClass('order__select__field__error');
            selectLabel.removeClass('order__checkout__form__label__error');
            selectLabel.find('span.order__text__label').removeClass('order__text__label__error');
        } else {
            searchInput.addClass('order__select__field__error');
            selectLabel.addClass('order__checkout__form__label__error');
            selectLabel.find('span.order__text__label').addClass('order__text__label__error');
        }
    }

;

        if (typeof currentLocale === 'undefined') {
            let currentLocale = 'br';
            let termsAndGdprTexts = {
                default: {
                    terms: `By placing this order you agree to the <a href='https://www.2co.com/terms.html?MOR=active' target='_blank'>Terms and Conditions</a>.`,
                    gdpr: `By completing my purchase I confirm that I am over 16 years of age and I agree to the <a href='https://www.2co.com/terms.html?MOR=active' target='_blank'>Terms and Conditions</a>.`
                },
                us: {
                    terms: `By placing the order with the auto-renewal option selected, you are confirming that you are over 16 years of age, and you agree that your license will automatically renew in accordance with the terms above (as such terms may be amended by mutual agreement), as well as with 2Checkout’s (now Verifone) <a href='https://www.2co.com/terms.html?MOR=active' target='_blank'>Terms and Conditions</a>.`,
                    gdpr: `By placing the order with the auto-renewal option selected, you are confirming that you are over 16 years of age, and you agree that your license will automatically renew in accordance with the terms above (as such terms may be amended by mutual agreement), as well as with 2Checkout’s (now Verifone) <a href='https://www.2co.com/terms.html?MOR=active' target='_blank'>Terms and Conditions</a>.`
                },
                gb: {
                    terms: `By placing the order with the auto-renewal option selected, you are confirming that you are over 16 years of age, and you agree that your license will automatically renew in accordance with the terms above (as such terms may be amended by mutual agreement), as well as with 2Checkout’s (now Verifone) <a href='https://www.2co.com/terms.html?MOR=active' target='_blank'>Terms and Conditions</a>.`,
                    gdpr: `By placing the order with the auto-renewal option selected, you are confirming that you are over 16 years of age, and you agree that your license will automatically renew in accordance with the terms above (as such terms may be amended by mutual agreement), as well as with 2Checkout’s (now Verifone) <a href='https://www.2co.com/terms.html?MOR=active' target='_blank'>Terms and Conditions</a>.`
                }
            };

            function showRenewalText() {
                let texts = (typeof(termsAndGdprTexts[currentLocale]) === 'object') ? termsAndGdprTexts[currentLocale] : termsAndGdprTexts.default;
                $('#order__common__terms__and__conditions').html(texts.terms);
                $('#order__gdpr__terms__and__conditions').html(texts.gdpr);
            }

            function hideRenewalTexts() {
                let texts = termsAndGdprTexts.default;
                $('#order__common__terms__and__conditions').html(texts.terms);
                $('#order__gdpr__terms__and__conditions').html(texts.gdpr);
            }

            $(document).ready(function() {
                $('#order__autorenewal').click(function() {
                    if ($(this).is(':checked')) {
                        showRenewalText();
                    } else {
                        hideRenewalTexts();
                    }
                });
                showRenewalText();
            });
        }
    ;

    jQuery(document).ready(function(){
                                    var payment_display_type = 'combo';
            
            //document.getElementById("payment");
            //var selected_value = 0;

                            FillSelectbox('state', 29);
                FillSelectbox('payment', 29);

                for (var i=0; i < available_payopt.length; i++) {
                    if (available_payopt.options[i].value == 1) {
                        available_payopt.options[i].selected = true;
                        available_payopt.selectedIndex = i;
                        //$(available_payopt).trigger('change');
                    }
                }

                                    for (var i=0; i < document.frmCheckout.state.length; i++) {
                        if (document.frmCheckout.state.options[i].value=="S\u00e3o Paulo") {
                            document.frmCheckout.state.options[i].selected = true;
                            document.frmCheckout.state.selectedIndex = i;
                        }
                    }
                            
            var __pay_option = 0;

            if ((payment_display_type == 'combo') && (document.frmCheckout.payment.options) &&
                document.frmCheckout.payment.options.hasOwnProperty(document.frmCheckout.payment.selectedIndex) ) {
                __pay_option = document.frmCheckout.payment.options[document.frmCheckout.payment.selectedIndex].value;
            } else if((payment_display_type == 'text') && (document.getElementById('payment').value)) {
                __pay_option = document.getElementById('payment').value;
            }

            FillSelectbox('billing_currency', __pay_option);

                        ShowAdditionalSection(__pay_option);

            displayDeliveryOptions(document.getElementById("gift_order"));
            showMessage(document.getElementById("payment"));

        
                    ShowExtraFields(29);
        
        
        
        
    });

    
    
    var autoSave = new CSaveAsYouType();
    $(document).ready(function(){
                    autoSave.addFocusElement('fullname');
                autoSave.addFocusElement('address', 'optional');
        autoSave.addFocusElement('address2', 'optional');
        autoSave.addFocusElement('city', 'optional');
        autoSave.addFocusElement('zipcode', 'optional');
        autoSave.addFocusElement('billingcountry', 'optional');
        autoSave.addFocusElement('state', 'optional');
        autoSave.addFocusElement('company', 'optional');
        autoSave.addFocusElement('fiscalcode', 'optional');
        autoSave.addFocusElement('phone', 'optional');
        autoSave.addFocusElement('fax', 'optional');
        autoSave.addFocusElement('custom', 'optional');
        autoSave.addFocusElement('email', 'mandatory', 'email');
        autoSave.active = true;
            });
;

    var payPalPaymentOption = 8;
    var payPalCreditPaymentOption = 83;
    var usCountry = 222;
;

        window.paypalCheckoutReady = function() {
            paypal.checkout.setup(_t_settings.paypalMerchantID, {
                locale: 'en_US',
                environment: 'production',
                button: ['checkoutSubmitBtn'],
                condition: function () {
                    return canOpenPaypalPopup();
                },
                                    click: function () {
                        initPayPalPopup();
                    }
                            });
        }
        jQuery(document).ready(function() {
            jQuery.ajax({
                url: "//www.paypalobjects.com/api/checkout.min.js",
                dataType: "script",
                cache: true,
                async: true
            });

            const thePayPalObserver = new MutationObserver(function(mutationsList) {
                mutationsList.forEach(function(mutation) {
                    if (mutation.type === 'childList') {
                        mutation.removedNodes.forEach(function(removedNode) {
                            if (removedNode.nodeType === 1 && $(removedNode).is('div[class^="paypal-checkout"]')) {
                                paypal.checkout.closeFlow();
                            }
                        });
                    }
                });
            });
            thePayPalObserver.observe(document.body, { childList: true, subtree: true });

        });
    ;

        $(document).ready(function(){
            ShoppingCartTracking.setTrackingLibUrl('//assets.adobedtm.com/0f18f8d4de82/cd75284beda8/launch-914a9c1a056c');
            ShoppingCartTracking.load(function(){
                // This is custom (Adobe DTM).
                ShoppingCartTracking.setTrackingCallback(_satellite.pageBottom);

                // Up-sell popup: Don't execute the tracking further.
                if (typeof omniture_vars != 'undefined'
                    && omniture_vars.UPSELL_DISPLAY_TYPE
                    && omniture_vars.UPSELL_DISPLAY_TYPE == 2) {
                    return true;
                }

                // Track the page load.
                ShoppingCartTracking.track('page-loaded');
            });
        });
    ;

var __order_steps = {STEP_1: "Shopping Cart",STEP_2: "Billing Information",STEP_3: "Confirmation and Payment",STEP_4: "Finish"},__order_processed_by = {WHO_IS_AVANGATE:    "Who is 2Checkout (now Verifone)?",TITLE:              "Your payment is securely processed by our partner, 2Checkout (now Verifone).",DESCRIPTION:        "For your convenience, we teamed up with 2Checkout (now Verifone) to provide a secure and reliable platform for selling our software products online. The whole ordering process is supported by 2Checkout (now Verifone), who handles all transaction data according to market security standards."},__order_check_if_company = "Check only if you are a company",__order_person_company = {RADIO_LABEL:    "Licensed to",PERSON:         "Person",COMPANY:        "Company"},__order_widgets = {I_HAVE_DISCOUNT_COUPON          :"I have a discount coupon",DOWNLOAD_VERSION                :"Download Version",DISCOUNT_COUPON                 :"Discount coupon",ADD_LABEL                       :"Add",PROCESSING_ORDER                :"Processing order",ORDER_PROCESSING                :"Processing order",PLEASE_WAIT                     :"Please wait",YOU_WILL_BE_CHARGED             :"You will be charged",PLACE_ORDER                     :"Place order",CONTINUE                        :"Continue",CCVSERRNUMBERSTRING             :"Invalid card number entered.",USER_DATA_ERROR                 :"Fields marked in red must be filled in correctly.",SECURE_CHECKOUT                 :"Secure Checkout",CREDIT_CARD_CVV                 :"Security code",CREDIT_CARDS                    :"Credit Cards",SELECT_OTHER_METHODS            :"Select other methods",NEW_PAYMENT_METHOD              :"New payment method",NG_INSTALMENTS_PRICE_WARNING    :"You also agree to pay your bank an extra installments fee of {0}. Total price: {1}.",OFFLINE_PAYMENT_MESSAGE         :"For {1}, product delivery takes place only after payment is received in full.<br>Paying by credit card usually offers you immediate access to the products you ordered.",ORDER_DUPLICATED                :"Our system detected this order as a duplicate, please click the button below if you want to place this order",APM_CART_MESSAGE_PAYPAL :               "You'll be redirected to PayPal to process your payment, which only takes a few seconds.",APM_CART_MESSAGE_SOFORTBANKING :        "We will redirect you to Sofort to finish the payment. This process usually takes a few minutes. Once you’ve completed the payment, we’ll deliver your order and return you to our order confirmation page. Alternatively, you can pay by credit card and get immediate access to the ordered products.",APM_CART_MESSAGE_GIROPAY :              "We will redirect you to our payment provider to finish the payment. This process usually takes a few minutes. Once you’ve completed the payment, we’ll deliver your order and return you to our order confirmation page. Alternatively, you can pay by credit card and get immediate access to the ordered products.",APM_CART_MESSAGE_DINERS :               "We will redirect you to our payment provider to finish the payment. This process usually takes a few minutes. Once you’ve completed the payment, we’ll deliver your order and return you to our order confirmation page.",APM_CART_MESSAGE_QIWI :                 "QIWI needs to validate your phone number before placing the order. After validating it, we'll redirect you to QIWI to finish the payment. Once you’ve completed payment, we’ll deliver your order.Alternatively, you can pay by credit card and get immediate access to the ordered products.",APM_CART_MESSAGE_WEBMONEY :             "We will redirect you to Webmoney to finish the payment. This process usually takes a few minutes. Once you’ve completed the payment, we’ll deliver your order and return you to our order confirmation page. Alternatively, you can pay by credit card and get immediate access to the ordered products.",APM_CART_MESSAGE_UNIONPAY :             "We will redirect you to UnionPay to finish the payment. This process usually takes a few minutes. Once you’ve completed the payment, we’ll deliver your order and return you to our order confirmation page. Alternatively, you can pay by credit card and get immediate access to the ordered products.",APM_CART_MESSAGE_ALIPAY :               "We will redirect you to Alipay to finish the payment. This process usually takes a few minutes. Once you’ve completed the payment, we’ll deliver your order and return you to our order confirmation page. Alternatively, you can pay by credit card and get immediate access to the ordered products.",APM_CART_MESSAGE_IDEAL :                "After selecting your bank we will redirect you to their website to finish the payment. This process usually takes a few minutes. Once you’ve completed payment, we’ll deliver your order and return you to our order confirmation page. Alternatively, you can pay by credit card and get immediate access to the ordered products.",APM_CART_MESSAGE_DIRECT_DEBIT_SEPA :    "We will charge your account after validating your payment information. This process usually takes 2 to 4 business days.Alternatively, you can pay by credit card and get immediate access to the ordered products.",APM_CART_MESSAGE_NORDEA :               "We will redirect you to Nordea to finish the payment. This process usually takes a few minutes. Once you’ve completed the payment, we’ll deliver your order and return you to our order confirmation page. Alternatively, you can pay by credit card and get immediate access to the ordered products.",APM_CART_MESSAGE_DANSKE :               "We will redirect you to Danske to finish the payment. This process usually takes a few minutes. Once you’ve completed the payment, we’ll deliver your order and return you to our order confirmation page. Alternatively, you can pay by credit card and get immediate access to the ordered products.",APM_CART_MESSAGE_OP_POHJOLA :           "We will redirect you to OP-Pohjola to finish the payment. This process usually takes a few minutes. Once you’ve completed the payment, we’ll deliver your order and return you to our order confirmation page. Alternatively, you can pay by credit card and get immediate access to the ordered products.",APM_CART_MESSAGE_TRUSTLY :              "We will redirect you to Trustly to finish the payment. This process usually takes a few minutes. Once you’ve completed the payment, we’ll deliver your order and return you to our order confirmation page. Alternatively, you can pay by credit card and get immediate access to the ordered products.",APM_CART_MESSAGE_POLI :                 "This payment is processed by Smart2Pay, our POLi trusted payment provider. This process usually takes a few minutes. Once you’ve completed the payment, we’ll deliver your order and return you to our order confirmation page. Alternatively, you can pay by credit card and get immediate access to the ordered products.",APM_CART_MESSAGE_ACH :                  "We will charge your account after validating your payment information. This process may take up to 5 business days. Alternatively, you can pay by credit card and get immediate access to the ordered products.",APM_CART_MESSAGE_ACH_INSTANT_AUTH :     "We will charge your account after validating your payment information. This process may take up to one day.",APM_CART_MESSAGE_KONBINI :              "For Konbini, product delivery takes place only after payment is received in full. This may take up to 2 business days. Your phone number is required to pay for your order.<br />Paying by credit card usually offers you immediate access to the products you ordered."};;


</script>


    
    
    <script>
  var quickSettings = {
    pricingOptionsDisplayType: 'popup', //possible values: popup, inline
    showMoneyBackBadge: false, //possible values: true, false
  }
</script>
<!-- Google Tag Manager-->
    <noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-PFK425" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager -->  
<SCRIPT src="/images/merchant/67caec8041b2d689a5035d3bf441c34c/LAYOUT_4_custom_template_bundle_min.js?20250618185757" language="javascript" type="text/javascript"></SCRIPT>

<script language="javascript" type="text/javascript">
  /**
  Version: 3.2.1
  Release date: 15 Jul 2020 
      Utilities & Dependencies:
      =========================
      - avaPage - Global object with current Shopping Cart context.
      - avaDebug - Enables debugging and avaLog().
      - avaLog(param, param, ...) - Used for console.log and fallback for older browsers, disabled if avaDebug true.
      - avaAppendImg(src, targetTag)
      - avaAppendScript(src, targetTag)
      - avaGUP(query, where) - Get URL Parameter
  */
  
  // Debug
  avaDebug = false;

  // When the DOM is ready.
  jQuery(document).ready(function($) {
  });
  
  // When the Window is loaded (DOM and resources).
  jQuery(window).load(function($) {
    // Your Code
  });
</script>
    
    
<script type="text/javascript">
	
	/* widgets that load automatically with every shopping cart */
$(document).ready(function() {
    // Initialize 'Skip Verify' (New Ordering Flow).
    try {
        var skipVerify = new __avng8_skip_verify();
    } catch(err) {
        try{
            console.log(err.message + err.lineNumber + err.fileName);
        } catch(err) {}
    }

    // Inline validation.
    try {

        __avng8_inline_validation();
    } catch(err) {
        try{
            console.log(err.message + err.lineNumber + err.fileName);
        } catch(err) {}
    }

    // DESIGN_TYPE=1
    try {
        //__avng8_payment_facade.setDebug(true);
        __avng8_payment_facade.init(skipVerify);
    } catch(err) {
        try{
            console.log(err.message + err.lineNumber + err.fileName);
        } catch(err) {}
    }

    //SSO authentication - payment with existing cards
    // DESIGN_TYPE!=1
    try {
        //__avng8_payment_facade.setDebug(true);
        __avng8_existing_cards.init();
    } catch(err) {
        try{
            console.log(err.message + err.lineNumber + err.fileName);
        } catch(err) {}
    }
});

console.log('Loaded jquery for: order_3.5.1_min');
console.log('Loaded jquery migrate version: '+ jQuery.migrateVersion );
console.log('Loaded jquery version: '+ jQuery().jquery );

jqueryUiVersion = $.ui ? $.ui.version || "pre 1.6" : 'jQuery-UI not detected';
console.log('Loaded jquery ui version: '+ jqueryUiVersion );

;


    // the Company field should always be visible for checkout_type = 'company', or for payment = 'purchase_order'
    $(document).bind('ready', function(){

        var checkBillCompanyMustBeVisible = function(){
            var checkout_type = $('input[name="checkout_type"]:checked').val(); // covers both the radio and checkbox layouts

            if (11 == $('#payment').val() || 'company' == checkout_type) {
                $('#bill_company').show();
            } else {
                //$('#bill_company').hide();
            }
        };

        // hack for forcing IE to fire the onchange event on radio buttons immediately after the click event gets
        // fired (otherwise, it wont fire unless the element gets blurred)
        if ($.browser.msie) {
            $('input:radio').click(function(){
                try {
                    this.blur();
                    this.focus();
                } catch (err) {
                    try{ console.log(err); } catch(err) {}
                }
            });
        }

        $('#payment').change(checkBillCompanyMustBeVisible);
        $('input[name="checkout_type"]').live($.browser.msie ? 'click' : 'change', checkBillCompanyMustBeVisible);
        checkBillCompanyMustBeVisible();
    });

;


		
</script>

    
    


    <script type="text/javascript" src="/_Incapsula_Resource?SWJIYLWA=719d34d31c8e3a6e6fffd425f7e032f3&ns=1&cb=2140782527" async></script></body>
    </html>
